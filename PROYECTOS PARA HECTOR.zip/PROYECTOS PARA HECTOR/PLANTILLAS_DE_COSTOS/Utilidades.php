<?php
include("Conn/conn.php");
error_reporting(E_ALL ^ E_NOTICE);
session_start();
if(!isset($_SESSION['user_name'])){
  echo "<script>alert('NO TIENES ACCESO AL ADMINISTRADOR !!!')</script>";
  echo "<script>window.open('login.php','_self')</script>";
}
else{ ?>
  <!DOCTYPE html>
  <html lang="es">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Utilidades</title>
    <link rel="icon" type="image/png" href="../img/icon/1.png">
    <link rel="stylesheet" href="Css/Boot.min.css">
    <link rel="stylesheet" href="Css/Esti.css">
  </head>
  <body>
    <nav class="navbar navbar-default">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">
              Toggle navigation
            </span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="index.php">
            Utilidades
          </a>
        </div>
        <div id="navbar" class="collapse navbar-collapse">
          <ul class="nav navbar-nav">
            <li>
              <a href="index.php">
                Panel de Control
              </a>
            </li>
            <li class="active">
              <a href="paginas.php">
                Páginas
              </a>
            </li>
            <li>
              <a href="usuarios.php">
                Usuarios
              </a>
            </li>
          </ul>
          <ul class="nav navbar-nav navbar-right">
            <li>
              <a href="index.php">
                Bienvenido, Utilidades
              </a>
            </li>
            <li>
              <a href="logout.php">
                Salir
              </a>
            </li>
          </ul>
        </div>
      </div>
    </nav>
    <header id="header">
      <div class="container">
        <div class="row">
          <div class="col-md-10">
            <h1>
              <span class="glyphicon glyphicon-cog" aria-hidden="true"></span>
                Páginas
              <small>
                Administrar Los Utilidades
              </small>
            </h1>
          </div>
          <div class="col-md-2">
            <div class="dropdown crear">
              <button class="btn btn-default dropdown-toggle" type="button" id="dropdownMenu1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
                Crear Contenido
                <span class="caret"></span>
              </button>
              <ul class="dropdown-menu" aria-labelledby="dropdownMenu1">
                <li>
                  <a type="button" data-toggle="modal" data-target="#addPage">
                    Agregar Una Nueva Utilidad.
                  </a>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </header>
    <section id="breadcrumb">
      <div class="container">
        <ol class="breadcrumb">
          <li>
            <a href="index.php">
              Panel de Control
            </a>
          </li>
          <li>
            Páginas
          </li>
          <li class="active">
            Ver Utilidades
          </li>
        </ol>
      </div>
    </section>
    <section id="main">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <div class="panel panel-default">
              <div class="panel-heading main-color-bg">
                <h3 class="panel-title">
                  NOMBRE DEL ESTABLECIMIENTO
                </h3>
              </div>
              <div class="panel-body table-responsive">
                <table class="table table-striped table-hover">
                  <tr>
                    <th>
                      ITEM:         
                    </th>
                    <th>
                      PRODUCTO:
                    </th>
                    <th>
                      PVP / USD:
                    </th>
                    <th>
                      FACTOR:
                    </th>
                    <th>
                      TOTAL PVP:
                    </th>
                    <th>
                      NEGOCIACIÓN VALOR:
                    </th>
                    <th>
                      NEGOCIACIÓN:
                    </th>
                    <th>
                      DESCUENTOS FINANCIEROS:
                    </th>
                    <th>
                      UTILIDAD BRUTA:
                    </th>
                  </tr>
                  <?php
                  mysqli_set_charset($mysqli, 'utf8');
                  $get_posts = "SELECT * FROM utilidades ORDER BY iditem DESC";
                  $run_posts = mysqli_query($mysqli, $get_posts);
                  while ($row_posts = mysqli_fetch_array($run_posts)) {
                    $Post_Item = $row_posts['iditem'];
                    $Post_Producto = $row_posts['producto'];
                    $Post_Pvp_Usd = $row_posts['pvpusd'];
                    $Post_Factor = $row_posts['factor'];
                    $Post_Total_Pvp = $row_posts['totalpvp'];
                    $Post_Negociacion_Valor = $row_posts['negociacionvalor'];
                    $Post_Descuentos_Financieros = $row_posts['descuentosfinancieros'];
                    $Post_Utilidad_Bruta = $row_posts['utilidadbruta'];
                    ?>
                    <tr>
                      <td>
                        <?php echo $Post_Item; ?>
                      </td>
                      <td>
                        <?php echo $Post_Producto; ?>
                      </td>
                      <td>
                        <?php echo $Post_Pvp_Usd; ?>
                      </td>
                      <td>
                        <?php echo $Post_Factor; ?>
                      </td>
                      <td>
                        <?php echo $Post_Total_Pvp; ?>
                      </td>
                      <td>
                        <?php echo $Post_Negociacion_Valor; ?>
                      </td>
                      <td>
                        <?php echo $Post_Descuentos_Financieros; ?>
                      </td>
                      <td>
                        <?php echo $Post_Utilidad_Bruta; ?>
                      </td>
                    </tr>
                  <?php } ?>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <footer id="footer">
      <p>
        Powered By Imaginaudio Digital, &copy; 2020
      </p>
    </footer>
    <div class="modal fade" id="addPage" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <form name="f" action="" method="post" enctype="multipart/form-data" target="_blank" >
            <div class="modal-header">
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">
                  &times;
                </span>
              </button>
              <h4 class="modal-title" id="myModalLabel">
                Agregar Utilidades
              </h4>
            </div>
            <div class="panel-body table-responsive">
              <div class="form-group">
                <label for="nombre">
                  ID PRINCIPAL:
                </label>
                <input type="text" name="IdPrincipal" class="form-control" value="" required="required"/>
              </div>
              <div class="form-group">
                <label for="nombre">
                  ITEM:
                </label>
                <input type="text" name="Iditem" class="form-control" value="" required="required"/>
              </div>
              <div class="form-group">
                <label for="nombre">
                  PRODUCTO:
                </label>
                <input type="text" name="NombProduct" class="form-control" value="" required="required"/>
              </div>
              <div class="form-group">
                <label for="nombre">
                  PVP / USD:
                </label>
                <input type="text" name="num1" value="0" onchange="calva()" onkeyup="calva()" class="form-control" value="" required="required"/>
              </div>
              <div class="form-group">
                <label for="nombre">
                  FACTOR:
                </label>
                <input type="text" name="num2" value="0" onchange="calva()" onkeyup="calva()" class="form-control" value="" required="required"/>
              </div>
              <div class="form-group">
                <label for="nombre">
                  TOTAL PVP:
                </label>
                <input type="text" name="sum" value="0" readonly="readonly" class="form-control" required="required"/>
              </div>
              <div class="form-group">
                <label for="nombre">
                  NEGOCIACIÓN VALOR:
                </label>
                <input type="text" name="num3" value="4100" readonly="readonly" onchange="calva()" onkeyup="calva()" class="form-control" value="" required="required"/>
              </div>
              <div class="form-group">
                <label for="nombre">
                  NEGOCIACIÓN:
                </label>
                <input type="text" name="sumneg" value="0" readonly="readonly" class="form-control" required="required"/>
              </div>
              <div class="form-group">
                <label for="nombre">
                  DESCUENTOS FINANCIEROS:
                </label>
                <input type="text" name="num4" value="0" onchange="calva()" onkeyup="calva()" class="form-control" value="" required="required"/>
              </div>
              <div class="form-group">
                <label for="autores">
                  UTILIDAD BRUTA:
                </label>
                <input type="text" name="sumval" value="0" readonly="readonly" class="form-control" required="required"/>
              </div>
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-default" data-dismiss="modal" style="height: 34px; border-radius: 4px; box-shadow: 5px 5px #888888; margin-right: 20px;">
                CERRAR
              </button>
              <input type="submit" name="GuardarUtilidad" value="GUARDAR UTILIDADES" id="EtiGuar" style="height: 34px; border-radius: 4px; box-shadow: 5px 5px #888888;"/>
            </div>
          </form>
        </div>
      </div>
    </div>
    <script src="Js/Jqu.min.js"></script>
    <script src="Js/Boot.min.js"></script>
       <script>
function calva() {
  try {
    var a = parseInt(document.f.num1.value),
        b = parseInt(document.f.num2.value);
    document.f.sum.value = a * b;
  } catch (e) {
  }
  try {
    var c = parseInt(document.f.num1.value),
        d = parseInt(document.f.num3.value);
    document.f.sumneg.value = c * d;
  } catch (e) {
  }
  try {
    var e = parseInt(document.f.sumneg.value),
        f = parseInt(document.f.num4.value);
    document.f.sumval.value = e - f;
  } catch (e) {
  }
}
</script>
  </body>
  </html>
  <?php
  if(isset($_POST['GuardarUtilidad'])){
  $post_IdPrincipal = $_POST['IdPrincipal'];      
  $Post_Id_Item = $_POST['Iditem'];
  $Post_Nomb_Product = $_POST['NombProduct'];
  $Post_Num1 = $_POST['num1'];
  $Post_Num2 = $_POST['num2'];
  $Post_Sum = $_POST['sum'];
  $Post_Num3 = $_POST['num3'];
  $Post_Sumeg = $_POST['sumneg'];
  $Post_Num4 = $_POST['num4'];
  $Post_Sumval = $_POST['sumval'];      
  mysqli_query($mysqli, "SET NAMES utf8");
  $Insert_Post = mysqli_query($mysqli, "INSERT INTO utilidades (id,iditem,producto,pvpusd,factor,totalpvp,negociacionvalor,negociacion,descuentosfinancieros,utilidadbruta) VALUES ('$post_IdPrincipal','$Post_Id_Item','$Post_Nomb_Product','$Post_Num1','$Post_Num2','$Post_Sum','$Post_Num3','$Post_Sumeg','$Post_Num4','$Post_Sumval')") or die (mysqli_error($mysqli));
      echo "<script>alert('UTILIDAD AGREGADA CON EXITO!!!')</script>";
      echo "<script>window.open('Utilidades.php','_self')</script>";
  }
  ?>
<?php } ?>