-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1:3306
-- Tiempo de generación: 12-05-2020 a las 19:14:24
-- Versión del servidor: 5.7.26
-- Versión de PHP: 7.2.18

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `plantilla`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `financieros`
--

DROP TABLE IF EXISTS `financieros`;
CREATE TABLE IF NOT EXISTS `financieros` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idreferencia` int(11) NOT NULL,
  `producto` varchar(1000) COLLATE utf8_spanish2_ci NOT NULL,
  `pvpusd` int(11) NOT NULL,
  `transporteinternacional` int(11) NOT NULL,
  `num1` int(11) NOT NULL,
  `num2` int(11) NOT NULL,
  `sum` int(11) NOT NULL,
  `num3` int(11) NOT NULL,
  `sumban` int(11) NOT NULL,
  `num4` int(11) NOT NULL,
  `sumpay` int(11) NOT NULL,
  `sumtot` int(11) NOT NULL,
  `num5` int(11) NOT NULL,
  `sumtrm` int(11) NOT NULL,
  `num6` int(11) NOT NULL,
  `sumdes` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

--
-- Volcado de datos para la tabla `financieros`
--

INSERT INTO `financieros` (`id`, `idreferencia`, `producto`, `pvpusd`, `transporteinternacional`, `num1`, `num2`, `sum`, `num3`, `sumban`, `num4`, `sumpay`, `sumtot`, `num5`, `sumtrm`, `num6`, `sumdes`) VALUES
(1, 1, 'Pantolones', 1222, 32131, 2323, 1, 23, 35, 8, 6, 139, 170, 3950, 671500, 23233, 694733);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `hojadecostos`
--

DROP TABLE IF EXISTS `hojadecostos`;
CREATE TABLE IF NOT EXISTS `hojadecostos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hojadecostosnum` int(11) NOT NULL,
  `idreferencia` int(11) NOT NULL,
  `descripcion` longtext COLLATE utf8_spanish2_ci NOT NULL,
  `coleccion` int(11) NOT NULL,
  `hojadecorte` int(11) NOT NULL,
  `FechaDeIngreso` timestamp NOT NULL ON UPDATE CURRENT_TIMESTAMP,
  `materiaprimna1` varchar(1000) COLLATE utf8_spanish2_ci NOT NULL,
  `materiaprimna2` varchar(100) COLLATE utf8_spanish2_ci NOT NULL,
  `materiaprimna3` varchar(100) COLLATE utf8_spanish2_ci NOT NULL,
  `materiaprimna4` varchar(100) COLLATE utf8_spanish2_ci NOT NULL,
  `materiaprimna5` varchar(100) COLLATE utf8_spanish2_ci NOT NULL,
  `materiaprimna6` varchar(100) COLLATE utf8_spanish2_ci NOT NULL,
  `materiaprimna7` varchar(100) COLLATE utf8_spanish2_ci NOT NULL,
  `materiaprimna8` varchar(100) COLLATE utf8_spanish2_ci NOT NULL,
  `materiaprimna9` varchar(100) COLLATE utf8_spanish2_ci NOT NULL,
  `materiaprimna10` varchar(100) COLLATE utf8_spanish2_ci NOT NULL,
  `materiaprimna11` varchar(100) COLLATE utf8_spanish2_ci NOT NULL,
  `materiaprimna12` varchar(100) COLLATE utf8_spanish2_ci NOT NULL,
  `materiaprimna13` varchar(100) COLLATE utf8_spanish2_ci NOT NULL,
  `materiaprimna14` varchar(100) COLLATE utf8_spanish2_ci NOT NULL,
  `materiaprimna15` varchar(100) COLLATE utf8_spanish2_ci NOT NULL,
  `proveedor1` varchar(1000) COLLATE utf8_spanish2_ci NOT NULL,
  `proveedor2` varchar(100) COLLATE utf8_spanish2_ci NOT NULL,
  `proveedor3` varchar(100) COLLATE utf8_spanish2_ci NOT NULL,
  `proveedor4` varchar(100) COLLATE utf8_spanish2_ci NOT NULL,
  `proveedor5` varchar(100) COLLATE utf8_spanish2_ci NOT NULL,
  `proveedor6` varchar(100) COLLATE utf8_spanish2_ci NOT NULL,
  `proveedor7` varchar(100) COLLATE utf8_spanish2_ci NOT NULL,
  `proveedor8` varchar(100) COLLATE utf8_spanish2_ci NOT NULL,
  `proveedor9` varchar(100) COLLATE utf8_spanish2_ci NOT NULL,
  `proveedor10` varchar(100) COLLATE utf8_spanish2_ci NOT NULL,
  `proveedor11` varchar(100) COLLATE utf8_spanish2_ci NOT NULL,
  `proveedor12` varchar(100) COLLATE utf8_spanish2_ci NOT NULL,
  `proveedor13` varchar(100) COLLATE utf8_spanish2_ci NOT NULL,
  `proveedor14` varchar(100) COLLATE utf8_spanish2_ci NOT NULL,
  `proveedor15` varchar(100) COLLATE utf8_spanish2_ci NOT NULL,
  `color1` varchar(1000) COLLATE utf8_spanish2_ci NOT NULL,
  `color2` varchar(100) COLLATE utf8_spanish2_ci NOT NULL,
  `color3` varchar(100) COLLATE utf8_spanish2_ci NOT NULL,
  `color4` varchar(100) COLLATE utf8_spanish2_ci NOT NULL,
  `color5` varchar(100) COLLATE utf8_spanish2_ci NOT NULL,
  `color6` varchar(100) COLLATE utf8_spanish2_ci NOT NULL,
  `color7` varchar(100) COLLATE utf8_spanish2_ci NOT NULL,
  `color8` varchar(100) COLLATE utf8_spanish2_ci NOT NULL,
  `color9` varchar(100) COLLATE utf8_spanish2_ci NOT NULL,
  `color10` varchar(100) COLLATE utf8_spanish2_ci NOT NULL,
  `color11` varchar(100) COLLATE utf8_spanish2_ci NOT NULL,
  `color12` varchar(100) COLLATE utf8_spanish2_ci NOT NULL,
  `color13` varchar(100) COLLATE utf8_spanish2_ci NOT NULL,
  `color14` varchar(100) COLLATE utf8_spanish2_ci NOT NULL,
  `color15` varchar(100) COLLATE utf8_spanish2_ci NOT NULL,
  `referenciadelatela1` varchar(1000) COLLATE utf8_spanish2_ci NOT NULL,
  `referenciadelatela2` varchar(100) COLLATE utf8_spanish2_ci NOT NULL,
  `referenciadelatela3` varchar(100) COLLATE utf8_spanish2_ci NOT NULL,
  `referenciadelatela4` varchar(100) COLLATE utf8_spanish2_ci NOT NULL,
  `referenciadelatela5` varchar(100) COLLATE utf8_spanish2_ci NOT NULL,
  `referenciadelatela6` varchar(100) COLLATE utf8_spanish2_ci NOT NULL,
  `referenciadelatela7` varchar(100) COLLATE utf8_spanish2_ci NOT NULL,
  `referenciadelatela8` varchar(100) COLLATE utf8_spanish2_ci NOT NULL,
  `referenciadelatela9` varchar(100) COLLATE utf8_spanish2_ci NOT NULL,
  `referenciadelatela10` varchar(100) COLLATE utf8_spanish2_ci NOT NULL,
  `referenciadelatela11` varchar(100) COLLATE utf8_spanish2_ci NOT NULL,
  `referenciadelatela12` varchar(100) COLLATE utf8_spanish2_ci NOT NULL,
  `referenciadelatela13` varchar(100) COLLATE utf8_spanish2_ci NOT NULL,
  `referenciadelatela14` varchar(100) COLLATE utf8_spanish2_ci NOT NULL,
  `referenciadelatela15` varchar(100) COLLATE utf8_spanish2_ci NOT NULL,
  `promedioporunaprenda1` int(11) NOT NULL,
  `promedioporunaprenda2` int(11) NOT NULL,
  `promedioporunaprenda3` int(11) NOT NULL,
  `promedioporunaprenda4` int(11) NOT NULL,
  `promedioporunaprenda5` int(11) NOT NULL,
  `promedioporunaprenda6` int(11) NOT NULL,
  `promedioporunaprenda7` int(11) NOT NULL,
  `promedioporunaprenda8` int(11) NOT NULL,
  `promedioporunaprenda9` int(11) NOT NULL,
  `promedioporunaprenda10` int(11) NOT NULL,
  `promedioporunaprenda11` int(11) NOT NULL,
  `promedioporunaprenda12` int(11) NOT NULL,
  `promedioporunaprenda13` int(11) NOT NULL,
  `promedioporunaprenda14` int(11) NOT NULL,
  `promedioporunaprenda15` int(11) NOT NULL,
  `valorunitariotela1` int(11) NOT NULL,
  `valorunitariotela2` int(11) NOT NULL,
  `valorunitariotela3` int(11) NOT NULL,
  `valorunitariotela4` int(11) NOT NULL,
  `valorunitariotela5` int(11) NOT NULL,
  `valorunitariotela6` int(11) NOT NULL,
  `valorunitariotela7` int(11) NOT NULL,
  `valorunitariotela8` int(11) NOT NULL,
  `valorunitariotela9` int(11) NOT NULL,
  `valorunitariotela10` int(11) NOT NULL,
  `valorunitariotela11` int(11) NOT NULL,
  `valorunitariotela12` int(11) NOT NULL,
  `valorunitariotela13` int(11) NOT NULL,
  `valorunitariotela14` int(11) NOT NULL,
  `valorunitariotela15` int(11) NOT NULL,
  `num1` int(11) NOT NULL,
  `num2` int(11) NOT NULL,
  `num3` int(11) NOT NULL,
  `num4` int(11) NOT NULL,
  `num5` int(11) NOT NULL,
  `num6` int(11) NOT NULL,
  `num7` int(11) NOT NULL,
  `num8` int(11) NOT NULL,
  `num9` int(11) NOT NULL,
  `num10` int(11) NOT NULL,
  `num11` int(11) NOT NULL,
  `num12` int(11) NOT NULL,
  `num13` int(11) NOT NULL,
  `num14` int(11) NOT NULL,
  `num15` int(11) NOT NULL,
  `sum` int(11) NOT NULL,
  `otroscostosdeproduccion` int(11) NOT NULL,
  `materiaprima16` varchar(1000) COLLATE utf8_spanish2_ci NOT NULL,
  `materiaprima17` varchar(100) COLLATE utf8_spanish2_ci NOT NULL,
  `materiaprima18` varchar(100) COLLATE utf8_spanish2_ci NOT NULL,
  `materiaprima19` varchar(100) COLLATE utf8_spanish2_ci NOT NULL,
  `materiaprima20` varchar(100) COLLATE utf8_spanish2_ci NOT NULL,
  `materiaprima21` varchar(100) COLLATE utf8_spanish2_ci NOT NULL,
  `materiaprima22` varchar(100) COLLATE utf8_spanish2_ci NOT NULL,
  `materiaprima23` varchar(100) COLLATE utf8_spanish2_ci NOT NULL,
  `materiaprima24` varchar(100) COLLATE utf8_spanish2_ci NOT NULL,
  `materiaprima25` varchar(100) COLLATE utf8_spanish2_ci NOT NULL,
  `materiaprima26` varchar(100) COLLATE utf8_spanish2_ci NOT NULL,
  `materiaprima27` varchar(100) COLLATE utf8_spanish2_ci NOT NULL,
  `materiaprima28` varchar(100) COLLATE utf8_spanish2_ci NOT NULL,
  `materiaprima29` varchar(100) COLLATE utf8_spanish2_ci NOT NULL,
  `materiaprima30` varchar(100) COLLATE utf8_spanish2_ci NOT NULL,
  `proveedor16` varchar(1000) COLLATE utf8_spanish2_ci NOT NULL,
  `proveedor17` varchar(100) COLLATE utf8_spanish2_ci NOT NULL,
  `proveedor18` varchar(100) COLLATE utf8_spanish2_ci NOT NULL,
  `proveedor19` varchar(100) COLLATE utf8_spanish2_ci NOT NULL,
  `proveedor20` varchar(100) COLLATE utf8_spanish2_ci NOT NULL,
  `proveedor21` varchar(100) COLLATE utf8_spanish2_ci NOT NULL,
  `proveedor22` varchar(100) COLLATE utf8_spanish2_ci NOT NULL,
  `proveedor23` varchar(100) COLLATE utf8_spanish2_ci NOT NULL,
  `proveedor24` varchar(100) COLLATE utf8_spanish2_ci NOT NULL,
  `proveedor25` varchar(100) COLLATE utf8_spanish2_ci NOT NULL,
  `proveedor26` varchar(100) COLLATE utf8_spanish2_ci NOT NULL,
  `proveedor27` varchar(100) COLLATE utf8_spanish2_ci NOT NULL,
  `proveedor28` varchar(100) COLLATE utf8_spanish2_ci NOT NULL,
  `proveedor29` varchar(100) COLLATE utf8_spanish2_ci NOT NULL,
  `proveedor30` varchar(100) COLLATE utf8_spanish2_ci NOT NULL,
  `color16` varchar(1000) COLLATE utf8_spanish2_ci NOT NULL,
  `color17` varchar(100) COLLATE utf8_spanish2_ci NOT NULL,
  `color18` varchar(100) COLLATE utf8_spanish2_ci NOT NULL,
  `color19` varchar(100) COLLATE utf8_spanish2_ci NOT NULL,
  `color20` varchar(100) COLLATE utf8_spanish2_ci NOT NULL,
  `color21` varchar(100) COLLATE utf8_spanish2_ci NOT NULL,
  `color22` varchar(100) COLLATE utf8_spanish2_ci NOT NULL,
  `color23` varchar(100) COLLATE utf8_spanish2_ci NOT NULL,
  `color24` varchar(100) COLLATE utf8_spanish2_ci NOT NULL,
  `color25` varchar(100) COLLATE utf8_spanish2_ci NOT NULL,
  `color26` varchar(100) COLLATE utf8_spanish2_ci NOT NULL,
  `color27` varchar(100) COLLATE utf8_spanish2_ci NOT NULL,
  `color28` varchar(100) COLLATE utf8_spanish2_ci NOT NULL,
  `color29` varchar(100) COLLATE utf8_spanish2_ci NOT NULL,
  `color30` varchar(100) COLLATE utf8_spanish2_ci NOT NULL,
  `referenciatela16` varchar(1000) COLLATE utf8_spanish2_ci NOT NULL,
  `referenciatela17` varchar(100) COLLATE utf8_spanish2_ci NOT NULL,
  `referenciatela18` varchar(100) COLLATE utf8_spanish2_ci NOT NULL,
  `referenciatela19` varchar(100) COLLATE utf8_spanish2_ci NOT NULL,
  `referenciatela20` varchar(100) COLLATE utf8_spanish2_ci NOT NULL,
  `referenciatela21` varchar(100) COLLATE utf8_spanish2_ci NOT NULL,
  `referenciatela22` varchar(100) COLLATE utf8_spanish2_ci NOT NULL,
  `referenciatela23` varchar(100) COLLATE utf8_spanish2_ci NOT NULL,
  `referenciatela24` varchar(100) COLLATE utf8_spanish2_ci NOT NULL,
  `referenciatela25` varchar(100) COLLATE utf8_spanish2_ci NOT NULL,
  `referenciatela26` varchar(100) COLLATE utf8_spanish2_ci NOT NULL,
  `referenciatela27` varchar(100) COLLATE utf8_spanish2_ci NOT NULL,
  `referenciatela28` varchar(100) COLLATE utf8_spanish2_ci NOT NULL,
  `referenciatela29` varchar(100) COLLATE utf8_spanish2_ci NOT NULL,
  `referenciatela30` varchar(100) COLLATE utf8_spanish2_ci NOT NULL,
  `promedioporunaprenda16` int(11) NOT NULL,
  `promedioporunaprenda17` int(11) NOT NULL,
  `promedioporunaprenda18` int(11) NOT NULL,
  `promedioporunaprenda19` int(11) NOT NULL,
  `promedioporunaprenda20` int(11) NOT NULL,
  `promedioporunaprenda21` int(11) NOT NULL,
  `promedioporunaprenda22` int(11) NOT NULL,
  `promedioporunaprenda23` int(11) NOT NULL,
  `promedioporunaprenda24` int(11) NOT NULL,
  `promedioporunaprenda25` int(11) NOT NULL,
  `promedioporunaprenda26` int(11) NOT NULL,
  `promedioporunaprenda27` int(11) NOT NULL,
  `promedioporunaprenda28` int(11) NOT NULL,
  `promedioporunaprenda29` int(11) NOT NULL,
  `promedioporunaprenda30` int(11) NOT NULL,
  `valorunitariodelatela16` int(11) NOT NULL,
  `valorunitariodelatela17` int(11) NOT NULL,
  `valorunitariodelatela18` int(11) NOT NULL,
  `valorunitariodelatela19` int(11) NOT NULL,
  `valorunitariodelatela20` int(11) NOT NULL,
  `valorunitariodelatela21` int(11) NOT NULL,
  `valorunitariodelatela22` int(11) NOT NULL,
  `valorunitariodelatela23` int(11) NOT NULL,
  `valorunitariodelatela24` int(11) NOT NULL,
  `valorunitariodelatela25` int(11) NOT NULL,
  `valorunitariodelatela26` int(11) NOT NULL,
  `valorunitariodelatela27` int(11) NOT NULL,
  `valorunitariodelatela28` int(11) NOT NULL,
  `valorunitariodelatela29` int(11) NOT NULL,
  `valorunitariodelatela30` int(11) NOT NULL,
  `num16` int(11) NOT NULL,
  `num17` int(11) NOT NULL,
  `num18` int(11) NOT NULL,
  `num19` int(11) NOT NULL,
  `num20` int(11) NOT NULL,
  `num21` int(11) NOT NULL,
  `num22` int(11) NOT NULL,
  `num23` int(11) NOT NULL,
  `num24` int(11) NOT NULL,
  `num25` int(11) NOT NULL,
  `num26` int(11) NOT NULL,
  `num27` int(11) NOT NULL,
  `num28` int(11) NOT NULL,
  `num29` int(11) NOT NULL,
  `num30` int(11) NOT NULL,
  `sumneg` int(11) NOT NULL,
  `cosotsdeproduccion` int(11) NOT NULL,
  `observacion` longtext COLLATE utf8_spanish2_ci NOT NULL,
  `num31` int(11) NOT NULL,
  `num32` int(11) NOT NULL,
  `composicion` varchar(1000) COLLATE utf8_spanish2_ci NOT NULL,
  `num33` int(11) NOT NULL,
  `sumval` int(11) NOT NULL,
  `num34` int(11) NOT NULL,
  `sumfabr` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

--
-- Volcado de datos para la tabla `hojadecostos`
--

INSERT INTO `hojadecostos` (`id`, `hojadecostosnum`, `idreferencia`, `descripcion`, `coleccion`, `hojadecorte`, `FechaDeIngreso`, `materiaprimna1`, `materiaprimna2`, `materiaprimna3`, `materiaprimna4`, `materiaprimna5`, `materiaprimna6`, `materiaprimna7`, `materiaprimna8`, `materiaprimna9`, `materiaprimna10`, `materiaprimna11`, `materiaprimna12`, `materiaprimna13`, `materiaprimna14`, `materiaprimna15`, `proveedor1`, `proveedor2`, `proveedor3`, `proveedor4`, `proveedor5`, `proveedor6`, `proveedor7`, `proveedor8`, `proveedor9`, `proveedor10`, `proveedor11`, `proveedor12`, `proveedor13`, `proveedor14`, `proveedor15`, `color1`, `color2`, `color3`, `color4`, `color5`, `color6`, `color7`, `color8`, `color9`, `color10`, `color11`, `color12`, `color13`, `color14`, `color15`, `referenciadelatela1`, `referenciadelatela2`, `referenciadelatela3`, `referenciadelatela4`, `referenciadelatela5`, `referenciadelatela6`, `referenciadelatela7`, `referenciadelatela8`, `referenciadelatela9`, `referenciadelatela10`, `referenciadelatela11`, `referenciadelatela12`, `referenciadelatela13`, `referenciadelatela14`, `referenciadelatela15`, `promedioporunaprenda1`, `promedioporunaprenda2`, `promedioporunaprenda3`, `promedioporunaprenda4`, `promedioporunaprenda5`, `promedioporunaprenda6`, `promedioporunaprenda7`, `promedioporunaprenda8`, `promedioporunaprenda9`, `promedioporunaprenda10`, `promedioporunaprenda11`, `promedioporunaprenda12`, `promedioporunaprenda13`, `promedioporunaprenda14`, `promedioporunaprenda15`, `valorunitariotela1`, `valorunitariotela2`, `valorunitariotela3`, `valorunitariotela4`, `valorunitariotela5`, `valorunitariotela6`, `valorunitariotela7`, `valorunitariotela8`, `valorunitariotela9`, `valorunitariotela10`, `valorunitariotela11`, `valorunitariotela12`, `valorunitariotela13`, `valorunitariotela14`, `valorunitariotela15`, `num1`, `num2`, `num3`, `num4`, `num5`, `num6`, `num7`, `num8`, `num9`, `num10`, `num11`, `num12`, `num13`, `num14`, `num15`, `sum`, `otroscostosdeproduccion`, `materiaprima16`, `materiaprima17`, `materiaprima18`, `materiaprima19`, `materiaprima20`, `materiaprima21`, `materiaprima22`, `materiaprima23`, `materiaprima24`, `materiaprima25`, `materiaprima26`, `materiaprima27`, `materiaprima28`, `materiaprima29`, `materiaprima30`, `proveedor16`, `proveedor17`, `proveedor18`, `proveedor19`, `proveedor20`, `proveedor21`, `proveedor22`, `proveedor23`, `proveedor24`, `proveedor25`, `proveedor26`, `proveedor27`, `proveedor28`, `proveedor29`, `proveedor30`, `color16`, `color17`, `color18`, `color19`, `color20`, `color21`, `color22`, `color23`, `color24`, `color25`, `color26`, `color27`, `color28`, `color29`, `color30`, `referenciatela16`, `referenciatela17`, `referenciatela18`, `referenciatela19`, `referenciatela20`, `referenciatela21`, `referenciatela22`, `referenciatela23`, `referenciatela24`, `referenciatela25`, `referenciatela26`, `referenciatela27`, `referenciatela28`, `referenciatela29`, `referenciatela30`, `promedioporunaprenda16`, `promedioporunaprenda17`, `promedioporunaprenda18`, `promedioporunaprenda19`, `promedioporunaprenda20`, `promedioporunaprenda21`, `promedioporunaprenda22`, `promedioporunaprenda23`, `promedioporunaprenda24`, `promedioporunaprenda25`, `promedioporunaprenda26`, `promedioporunaprenda27`, `promedioporunaprenda28`, `promedioporunaprenda29`, `promedioporunaprenda30`, `valorunitariodelatela16`, `valorunitariodelatela17`, `valorunitariodelatela18`, `valorunitariodelatela19`, `valorunitariodelatela20`, `valorunitariodelatela21`, `valorunitariodelatela22`, `valorunitariodelatela23`, `valorunitariodelatela24`, `valorunitariodelatela25`, `valorunitariodelatela26`, `valorunitariodelatela27`, `valorunitariodelatela28`, `valorunitariodelatela29`, `valorunitariodelatela30`, `num16`, `num17`, `num18`, `num19`, `num20`, `num21`, `num22`, `num23`, `num24`, `num25`, `num26`, `num27`, `num28`, `num29`, `num30`, `sumneg`, `cosotsdeproduccion`, `observacion`, `num31`, `num32`, `composicion`, `num33`, `sumval`, `num34`, `sumfabr`) VALUES
(1, 1, 1, 'rtrfg', 1, 1, '2020-05-12 23:53:00', 'a', 'a', 'a', 'a', 'a', 'a', 'a', 'a', 'a', 'a', 'a', 'a', 'a', 'a', 'a', 'a', 'a', 'a', 'a', 'a', 'a', 'a', 'a', 'a', 'a', 'a', 'a', 'a', 'a', 'a', 'a', 'a', 'a', 'a', 'a', 'a', 'a', 'a', 'a', 'aa', 'a', 'a', 'a', 'a', 'a', 'a', 'a', 'a', 'a', 'a', 'a', 'a', 'a', 'a', 'a', 'a', 'a', 'a', 'a', 'a', 2345, 5435, 435435, 453, 35664, 53656, 565, 636, 536536, 35653, 6536, 536536, 53635, 6356, 356, 345, 455, 345, 3445, 545, 5435, 43543, 45, 4545, 545, 54354, 3643, 4364, 64, 346, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 15, 1, 'dsf', 'dsfds', 'df', 'dsf', 'dfdsf', 'fdsf', 'sdfds', 'fdsf', 'sfsd', 'dsfd', 'dsf', 'sd', 'fsd', 'dsf', 'sdf', 'dsf', 'dsf', 'dsf', 'dsfds', 'fdsf', 'dsfds', 'fdsf', 'dsf', 'dsfds', 'sf', 'dsfds', 'fds', 'fsdf', 'sdf', 'sdf', 'trer', 'ter', 'tre', 'tret', 'ret', 'ert', 'ert', 're', 'tret', 'tre', 'uyg8u', 'ojmoikn', 'mkm', 'mnoko', 'dfdsf', 't', 't', 'tret', 'ertre', 'rt', 'ret', 'rt', 'rtre', 'g', 'trrt', 'r', 'f', 'd', 'd', 'a', 3454, 435, 43, 435, 543, 534, 34, 45, 45345, 4354, 435, 345, 543, 5435, 34534, 45435, 5, 435, 435, 543, 5345, 53, 345, 5435, 3543, 435435, 43543, 534534, 435, 5, 54654, 54654, 45654, 5465, 4565, 5463, 2340, 324, 324, 432, 43, 234, 423, 234, 2, 174811, 1, 'sfdtgfgfdg', 1, 1, 'wewewre', 1, 3, 1, 4);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `registrodeoperacíon`
--

DROP TABLE IF EXISTS `registrodeoperacíon`;
CREATE TABLE IF NOT EXISTS `registrodeoperacíon` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `mes` varchar(1000) COLLATE utf8_spanish2_ci NOT NULL,
  `cuenta` int(11) NOT NULL,
  `naturaleza` int(11) NOT NULL,
  `nombrebanco` varchar(1000) COLLATE utf8_spanish2_ci NOT NULL,
  `FechaDeIngreso` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `idfactura` int(11) NOT NULL,
  `num1` int(11) NOT NULL,
  `num3` int(11) NOT NULL,
  `tdc` int(11) NOT NULL,
  `directo` int(11) NOT NULL,
  `num2` int(11) NOT NULL,
  `sum` int(11) NOT NULL,
  `num4` int(11) NOT NULL,
  `sumban` int(11) NOT NULL,
  `sumcam` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

--
-- Volcado de datos para la tabla `registrodeoperacíon`
--

INSERT INTO `registrodeoperacíon` (`id`, `mes`, `cuenta`, `naturaleza`, `nombrebanco`, `FechaDeIngreso`, `idfactura`, `num1`, `num3`, `tdc`, `directo`, `num2`, `sum`, `num4`, `sumban`, `sumcam`) VALUES
(1, 'Abril', 1, 1, 'Bancolombia', '2020-05-12 12:03:00', 1, 10000, 3600, 2000, 2000, 2000, 300, 3000000, 4000, 14400000);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(400) COLLATE utf8_spanish_ci NOT NULL,
  `user_password` varchar(400) COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `users`
--

INSERT INTO `users` (`id`, `user_name`, `user_password`) VALUES
(1, 'plantilladecostos', 'plantilladecostos2020');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `utilidades`
--

DROP TABLE IF EXISTS `utilidades`;
CREATE TABLE IF NOT EXISTS `utilidades` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `iditem` int(11) NOT NULL,
  `producto` varchar(10000) COLLATE utf8_spanish2_ci NOT NULL,
  `pvpusd` int(11) NOT NULL,
  `factor` int(11) NOT NULL,
  `totalpvp` int(11) NOT NULL,
  `negociacionvalor` int(11) NOT NULL,
  `negociacion` int(11) NOT NULL,
  `descuentosfinancieros` int(11) NOT NULL,
  `utilidadbruta` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

--
-- Volcado de datos para la tabla `utilidades`
--

INSERT INTO `utilidades` (`id`, `iditem`, `producto`, `pvpusd`, `factor`, `totalpvp`, `negociacionvalor`, `negociacion`, `descuentosfinancieros`, `utilidadbruta`) VALUES
(1, 1, 'Legis', 212, 344, 72928, 4100, 869200, 3434, 865766);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
