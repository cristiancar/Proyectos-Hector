<?php
include("Conn/conn.php");
session_start();
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Plantillas De Costos | Acceso | Usuarios</title>
  <link rel="icon" type="image/png" href="../img/icon/1.png">
  <link rel="stylesheet" href="Css/Boot.min.css">
  <link rel="stylesheet" href="Css/Esti.css">
</head>
<body>
  <nav class="navbar navbar-default">
    <div class="container">
      <div class="navbar-header">
        <a class="navbar-brand" href="login.php">
          Plantillas De Costos
        </a>
      </div>
    </div>
  </nav>
  <header id="header">
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <h1 class="text-center">
            Administración
            <small>
              Acceso Usuarios
            </small>
          </h1>
        </div>
      </div>
    </div>
  </header>
  <section id="main">
    <div class="container">
      <div class="row">
        <div class="col-md-4 col-md-offset-4">
          <form method="post" id="login" action="login.php" class="well">
            <div class="form-group">
              <label>
                USUARIO:
              </label>
              <input type="text" class="form-control" name="username" placeholder="Ingrese El Usuario" required="required">
            </div>
            <div class="form-group">
              <label>
                CONTRASEÑA:
              </label>
              <input type="password" class="form-control" name="pass" placeholder="Ingrese La Contraseña" required="required">
            </div>
            <input type="submit" class="btn btn-primary btn-block" name="login" value="Acceder"></input>
          </form>
        </div>
      </div>
    </div>
  </section>
  <footer id="FooterLo">
    <p>
      Powered By Imaginaudio Digital, &copy; 2020
    </p>
  </footer>
  <script src="Js/Jqu.min.js"></script>
  <script src="Js/Boot.min.js"></script>
</body>
</html>
<?php
if(isset($_POST['login'])){
  $user_name = mysqli_real_escape_string($mysqli, $_POST['username']);
  $user_pass = mysqli_real_escape_string($mysqli, $_POST['pass']);   
  $select_user = "select * from users where user_name='$user_name' AND user_password='$user_pass'";
  $run_user = mysqli_query($mysqli, $select_user);
  if(mysqli_num_rows($run_user)>0){
    $_SESSION['user_name']=$user_name;
    echo "<script>alert('BIENVENIDO AL ADMINISTRADOR DE PLANTILLAS DE COSOTOS ¡¡¡')</script>";
    echo "<script>window.open('index.php','_self')</script>";
  }
  else{
    echo "<script>alert('NOMBRE Ó CONTRASEÑA INCORRECTOS')</script>";
    echo "<script>window.open('login.php','_self')</script>";
  }
} ?>