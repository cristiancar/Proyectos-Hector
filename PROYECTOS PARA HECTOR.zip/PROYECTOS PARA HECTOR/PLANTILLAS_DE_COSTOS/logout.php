<?php
session_start();
session_destroy();
echo "<script>alert('ADMNINISTRADOR FINAIADO')</script>";
echo "<script>window.open('login.php','_self')</script>";