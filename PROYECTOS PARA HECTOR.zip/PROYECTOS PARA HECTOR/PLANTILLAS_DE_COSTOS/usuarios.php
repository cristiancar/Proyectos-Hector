<?php
include("Conn/conn.php");
error_reporting(E_ALL ^ E_NOTICE);
session_start();
if(!isset($_SESSION['user_name'])){
  echo "<script>alert('NO TIENES ACCESO AL ADMINISTRADOR !!!')</script>";
  echo "<script>window.open('login.php','_self')</script>";
}
else{ ?>
  <!DOCTYPE html>
  <html lang="es">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Plantillas De Costos | Ver | Usuarios</title>
    <link rel="icon" type="image/png" href="../img/icon/1.png">
    <link rel="stylesheet" href="Css/Boot.min.css">
    <link rel="stylesheet" href="Css/Esti.css">
  </head>
  <body>
    <nav class="navbar navbar-default">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">
              Toggle navigation
            </span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="index.php">
            Plantillas De Costos
          </a>
        </div>
        <div id="navbar" class="collapse navbar-collapse">
          <ul class="nav navbar-nav">
            <li>
              <a href="index.php">
                Panel de Control
              </a>
            </li>
            <li>
              <a href="paginas.php">
                Páginas
              </a>
            </li>
            <li class="active">
              <a href="usuarios.php">
                Usuarios
              </a>
            </li>
          </ul>
          <ul class="nav navbar-nav navbar-right">
            <li>
              <a href="index.php">
                Bienvenidos, Plantillas De Costos
              </a>
            </li>
            <li>
              <a href="logout.php">
                Salir
              </a>
            </li>
          </ul>
        </div>
      </div>
    </nav>
    <header id="header">
      <div class="container">
        <div class="row">
          <div class="col-md-10">
            <h1>
              <span class="glyphicon glyphicon-cog" aria-hidden="true"></span>
                Usuarios
              <small>
                Administrar Usuarios
              </small>
            </h1>
          </div>
        </div>
      </div>
    </header>
    <section id="breadcrumb">
      <div class="container">
        <ol class="breadcrumb">
          <li>
            <a href="index.php">
              Panel de Control
            </a>
          </li>
          <li class="active">
            Usuarios
          </li>
        </ol>
      </div>
    </section>
    <section id="main">
      <div class="container">
        <div class="row">
          <div class="col-md-3">
            <div class="list-group">
              <a href="index.php" class="list-group-item active color-principal">
                <span class="glyphicon glyphicon-cog" aria-hidden="true"></span>
                  Panel de Control
              </a>
              <a href="paginas.php" class="list-group-item">
                <span class="glyphicon glyphicon-list-alt" aria-hidden="true"></span>
                  Páginas
                <span class="badge">
                  5
                </span>
              </a>
              <a href="usuarios.php" class="list-group-item">
                <span class="glyphicon glyphicon-user" aria-hidden="true"></span>
                  Usuarios
                <span class="badge">
                  1
                </span>
              </a>
            </div>
          </div>
          <div class="col-md-9">
            <div class="panel panel-default">
              <div class="panel-heading main-color-bg">
                <h3 class="panel-title">
                  Usuarios
                </h3>
              </div>
              <div class="panel-body table-responsive">
                <br>
                <table class="table table-striped table-hover">                  
                  <tr>
                    <th>
                      NOMBRE
                    </th>
                    <th>
                      EMAIL
                    </th>
                    <th>
                      REGISTRADO
                    </th>
                  </tr>
                  <tr>
                    <?php
                    mysqli_set_charset($mysqli, 'utf8');
                    $select_post = "select * from users ";
                    $run_query = mysqli_query($mysqli, $select_post);
                    while ($row_post = mysqli_fetch_array($run_query)) {
                      $post_usuario = $row_post['user_name']; ?>
                      <td>
                        <?php echo $post_usuario; ?>
                      </td>
                      <td>
                        Plantillasdecostos@gmail.com
                      </td>
                      <td>
                        11 DE MAYO 2020
                      </td>
                    <?php } ?>
                  </tr>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <footer id="footer">
      <p>
        Powered By Imaginaudio Digital, &copy; 2020
      </p>
    </footer>
    <script src="Js/Jqu.min.js"></script>
    <script src="Js/Boot.min.js"></script>
  </body>
  </html>
<?php } ?>