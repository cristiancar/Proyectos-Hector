<?php
include("Conn/conn.php");
error_reporting(E_ALL ^ E_NOTICE);
session_start();
if(!isset($_SESSION['user_name'])){
  echo "<script>alert('NO TIENES ACCESO AL ADMINISTRADOR !!!')</script>";
  echo "<script>window.open('login.php','_self')</script>";
}
else{ ?>
  <!DOCTYPE html>
  <html lang="es">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Hoja De Costos</title>
    <link rel="icon" type="image/png" href="../img/icon/1.png">
    <link rel="stylesheet" href="Css/Boot.min.css">
    <link rel="stylesheet" href="Css/Esti.css">
  </head>
  <body>
    <nav class="navbar navbar-default">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">
              Toggle navigation
            </span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="index.php">
            Hoja De Costos
          </a>
        </div>
        <div id="navbar" class="collapse navbar-collapse">
          <ul class="nav navbar-nav">
            <li>
              <a href="index.php">
                Panel de Control
              </a>
            </li>
            <li class="active">
              <a href="paginas.php">
                Páginas
              </a>
            </li>
            <li>
              <a href="usuarios.php">
                Usuarios
              </a>
            </li>
          </ul>
          <ul class="nav navbar-nav navbar-right">
            <li>
              <a href="index.php">
                Bienvenido, Hoja De Costos
              </a>
            </li>
            <li>
              <a href="logout.php">
                Salir
              </a>
            </li>
          </ul>
        </div>
      </div>
    </nav>
    <header id="header">
      <div class="container">
        <div class="row">
          <div class="col-md-10">
            <h1>
              <span class="glyphicon glyphicon-cog" aria-hidden="true"></span>
                Páginas
              <small>
                Administrar Los Hoja De Costos
              </small>
            </h1>
          </div>
          <div class="col-md-2">
            <div class="dropdown crear">
              <button class="btn btn-default dropdown-toggle" type="button" id="dropdownMenu1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
                Crear Contenido
                <span class="caret"></span>
              </button>
              <ul class="dropdown-menu" aria-labelledby="dropdownMenu1">
                <li>
                  <a type="button" data-toggle="modal" data-target="#addPage">
                    Agregar Una Hoja De Costos
                  </a>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </header>
    <section id="breadcrumb">
      <div class="container">
        <ol class="breadcrumb">
          <li>
            <a href="index.php">
              Panel de Control
            </a>
          </li>
          <li>
            Páginas
          </li>
          <li class="active">
            Ver Hoja De Costos
          </li>
        </ol>
      </div>
    </section>
    <section id="main">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <div class="panel panel-default">
              <div class="panel-heading main-color-bg">
                <h3 class="panel-title">
                  NOMBRE DEL ESTABLECIMIENTO
                </h3>
              </div>
              <div class="panel-body table-responsive">
                <table class="table table-striped table-hover">
                  <tr>
                    <th>
                      HOJA DE COSTOS N°:
                    </th>
                    <th>
                      REFERENCIA:
                    </th>
                    <th>
                      DESCRICIÓN:
                    </th>
                    <th>
                      COLECCIÓN:
                    </th>
                    <th>
                      HOJA DE CORTE:
                    </th>
                    <th>
                      FECHA:
                    </th>
                    <th>
                      MATERIA PRIMA
                    </th>
                    <th>
                      PROVEEDOR
                    </th>
                    <th>
                      COLOR
                    </th>
                    <th>
                      REF DE TELA
                    </th>
                    <th>
                      PROMEDIO POR UNA PRENDA
                    </th>
                    <th>
                      VALOR UNITARIO TELA
                    </th>
                    <th>
                      VALOR TOTAL
                    </th>
                    <th>
                      TOTAL MATERIA PRIMA:
                    </th>
                    <th>
                      OTROS COSTOS DE PRODUCIÓN:
                    </th>
                    <th>
                      MATERIA PRIMA
                    </th>
                    <th>
                      PROVEEDOR
                    </th>
                    <th>
                      COLOR
                    </th>
                    <th>
                      REF DE TELA
                    </th>
                    <th>
                      PROMEDIO POR UNA PRENDA
                    </th>
                    <th>
                      VALOR UNITARIO TELA
                    </th>
                    <th>
                      VALOR TOTAL
                    </th>
                    <th>
                      TOTAL OTROS COSTOS DE PRODUCIÓN:
                    </th>
                    <th>
                      COSTOS INDIRECTOS DE FABRICACIÓN:
                    </th>
                    <th>
                      OBSERVACIÓN:
                    </th>
                    <th>
                      SUBTOTALES MATERIALES:
                    </th>
                    <th>
                      SUBTOTAL COSTOS PCCIÓN:
                    </th>
                    <th>
                      COMPOSICIÓN:
                    </th>
                    <th>
                      MARGEN DE SEGURIDAD:
                    </th>
                    <th>
                      SUBTOTAL:
                    </th>
                    <th>
                      COSTOS INDIRECTOS:
                    </th>
                    <th>
                      VALOR EN FABRICA:
                    </th>
                  </tr>
                  <?php
                  mysqli_set_charset($mysqli, 'utf8');
                  $get_posts = "SELECT * FROM hojadecostos ORDER BY hojadecostosnum DESC";
                  $run_posts = mysqli_query($mysqli, $get_posts);
                  while ($row_posts = mysqli_fetch_array($run_posts)) {
                    $Post_Hoja_De_Costos_N° = $row_posts['hojadecostosnum'];
                    $Post_Referencia = $row_posts['idreferencia'];
                    $Post_Descripcion = $row_posts['descripcion'];
                    $Post_Coleccion = $row_posts['coleccion'];
                    $Post_Hoja_De_Corte = $row_posts['hojadecorte'];
                    $Post_Fecha = $row_posts['FechaDeIngreso'];
                    $Post_Proveedor = $row_posts['proveedor'];
                    $Post_Color = $row_posts['color'];
                    $Post_Ref_De_Tela = $row_posts['referenciadelatela'];
                    $Post_Promedio_Por_Una_Prenda = $row_posts['promedioporunaprenda'];
                    $Post_Valor_Unitario_Tela = $row_posts['valorunitariotela'];
                    $Post_Valor_Total = $row_posts['valortotal'];
                    $Post_Total_Materia_Prima = $row_posts['totalmateriaprima'];
                    $Post_Otros_Costos_De_Producción = $row_posts['otroscostosdeproduccion'];
                    $Post_Materia_Prima_2 = $row_posts['materiaprima2'];
                    $Post_Proveedor_2 = $row_posts['proveedor2'];
                    $Post_Color_2 = $row_posts['color2'];
                    $Post_Ref_De_Tela_2 = $row_posts['referenciatela2'];
                    $Post_Promedio_Por_Una_Prenda = $row_posts['promedioporunaprenda'];
                    $Post_Valor_Unitario_Tela = $row_posts['valorunitariodelatela'];
                    $Post_Valor_Total = $row_posts['valortotal'];
                    $Post_Total_Otros_Costos_De_Produccion = $row_posts['totalotroscostosdeproduccion'];
                    $Post_Observacion = $row_posts['observacion'];
                    $Post_Subtotales_Materiales = $row_posts['subtotalesmateriales'];
                    $Post_Subtotal_Costos_Pccion = $row_posts['subtotalcostospccion'];
                    $Post_Composición = $row_posts['composicion'];
                    $Post_Margen_De_Seguridad = $row_posts['margendeseguridad'];
                    $Post_Costos_Indirectos = $row_posts['costosindirectos'];
                    $Post_Valor_En_Fabrica = $row_posts['valorenfabrica'];
                    ?>
                    <tr>
                      <td>
                        <?php echo $Post_Hoja_De_Costos_N°; ?>
                      </td>
                      <td>
                        <?php echo $Post_Referencia; ?>
                      </td>
                      <td>
                        <?php echo $Post_Descripcion; ?>
                      </td>
                      <td>
                        <?php echo $Post_Coleccion; ?>
                      </td>
                      <td>
                        <?php echo $Post_Hoja_De_Corte; ?>
                      </td>
                      <td>
                        <?php echo $Post_Fecha; ?>
                      </td>
                      <td>
                        <?php echo $Post_Materia_Prima; ?>
                      </td>
                      <td>
                        <?php echo $Post_Proveedor; ?>
                      </td>
                      <td>
                        <?php echo $Post_Color; ?>
                      </td>
                      <td>
                        <?php echo $Post_Ref_De_Tela; ?>
                      </td>
                      <td>
                        <?php echo $Post_Promedio_Por_Una_Prenda; ?>
                      </td>
                      <td>
                        <?php echo $Post_Valor_Unitario_Tela; ?>
                      </td>
                      <td>
                        <?php echo $Post_Valor_Total; ?>
                      </td>
                      <td>
                        <?php echo $Post_Total_Materia_Prima; ?>
                      </td>
                      <td>
                        <?php echo $Post_Otros_Costos_De_Producción; ?>
                      </td>
                      <td>
                        <?php echo $Post_Materia_Prima_2; ?>
                      </td>
                      <td>
                        <?php echo $Post_Proveedor_2; ?>
                      </td>
                      <td>
                        <?php echo $Post_Color_2; ?>
                      </td>
                      <td>
                        <?php echo $Post_Ref_De_Tela_2; ?>
                      </td>
                      <td>
                        <?php echo $Post_Promedio_Por_Una_Prenda; ?>
                      </td>
                      <td>
                        <?php echo $Post_Valor_Unitario_Tela; ?>
                      </td>
                      <td>
                        <?php echo $Post_Valor_Total; ?>
                      </td>
                      <td>
                        <?php echo $Post_Total_Otros_Costos_De_Produccion; ?>
                      </td>
                      <td>
                        <?php echo $Post_Costos_Indirectos_De_Produccion; ?>
                      </td>
                      <td>
                        <?php echo $Post_Observacion; ?>
                      </td>
                      <td>
                        <?php echo $Post_Subtotales_Materiales; ?>
                      </td>
                      <td>
                        <?php echo $Post_Subtotal_Costos_Pccion; ?>
                      </td>
                      <td>
                        <?php echo $Post_Composición; ?>
                      </td>
                      <td>
                        <?php echo $Post_Margen_De_Seguridad; ?>
                      </td>
                      <td>
                        <?php echo $Post_Subtotal; ?>
                      </td>
                      <td>
                        <?php echo $Post_Costos_Indirectos; ?>
                      </td>
                      <td>
                        <?php echo $Post_Valor_En_Fabrica; ?>
                      </td>
                    </tr>
                  <?php } ?>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <footer id="footer">
      <p>
        Powered By Imaginaudio Digital, &copy; 2020
      </p>
    </footer>
    <div class="modal fade" id="addPage" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <form name="f" action="" method="post" enctype="multipart/form-data" target="_blank" >
            <div class="modal-header">
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">
                  &times;
                </span>
              </button>
              <h4 class="modal-title" id="myModalLabel">
                Agregar Hoja De Costos
              </h4>
            </div>
            <div class="panel-body table-responsive">
              <div class="form-group">
                <label for="nombre">
                  ID PRINCIPAL:
                </label>
                <input type="text" name="IdPrincipal" class="form-control" value="" required="required"/>
              </div>
              <div class="form-group">
                <label for="nombre">
                  HOJA DE COSTOS N°:
                </label>
                <input type="text" name="hojadecostosnum" class="form-control" value="" required="required"/>
              </div>
              <div class="form-group">
                <label for="nombre">
                  REFERENCIA:
                </label>
                <input type="text" name="idreferencia" class="form-control" value="" required="required"/>
              </div>
              <div class="form-group">
                <label for="nombre">
                  DESCRICIÓN:
                </label>
                <textarea class="form-control" name="descripcion" required="required"></textarea>
              </div>
              <div class="form-group">
                <label for="nombre">
                  COLECCIÓN:
                </label>
                <input type="text" name="coleccion" class="form-control" value="" required="required"/>
              </div>
              <div class="form-group">
                <label for="nombre">
                  HOJA DE CORTE:
                </label>
                <input type="text" name="hojadecorte" class="form-control" value="" required="required"/>
              </div>
              <div class="form-group">
                <label>
                  FECHA:
                </label>
                <input type="datetime-local" class="form-control" name="FechaDeIngreso" value="<?php echo date('Y-m-d').'T'.date('H:i'); ?>" required="required">
              </div>
              <table class="table table-responsive table-striped">
                <thead>
                  <tr>
                    <th>
                      <label for="nombre">
                        MATERIA PRIMA
                      </label>
                    </th>
                    <th>
                      <label for="nombre">
                        PROVEEDOR
                      </label>
                    </th>
                    <th>
                      <label for="nombre">
                        COLOR
                      </label>
                    </th>
                    <th>
                      <label for="nombre">
                        REF DE TELA
                      </label>
                    </th>
                    <th>
                      <label for="nombre">
                        PROMEDIO POR UNA PRENDA
                      </label>
                    </th>
                    <th>
                      <label for="nombre">
                        VALOR UNITARIO TELA
                      </label>
                    </th>
                    <th>
                      <label for="nombre">
                        VALOR TOTAL
                      </label>
                    </th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td>
                      <input type="text" name="materiaprimna1" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="proveedor1" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="color1" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="referenciadelatela1" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="promedioporunaprenda1" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="valorunitariotela1" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="num1" value="0" onchange="calva()" onkeyup="calva()" class="form-control" value="" required="required"/>
                    </td>
                  </tr>
                  <tr>
                    <td>
                      <input type="text" name="materiaprimna2" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="proveedor2" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="color2" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="referenciadelatela2" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="promedioporunaprenda2" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="valorunitariotela2" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="num2" value="0" onchange="calva()" onkeyup="calva()" class="form-control" value="" required="required"/>
                    </td>
                  </tr>
                  <tr>
                    <td>
                      <input type="text" name="materiaprimna3" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="proveedor3" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="color3" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="referenciadelatela3" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="promedioporunaprenda3" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="valorunitariotela3" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="num3" value="0" onchange="calva()" onkeyup="calva()" class="form-control" value="" required="required"/>
                    </td>
                  </tr>
                  <tr>
                    <td>
                      <input type="text" name="materiaprimna4" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="proveedor4" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="color4" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="referenciadelatela4" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="promedioporunaprenda4" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="valorunitariotela4" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="num4" value="0" onchange="calva()" onkeyup="calva()" class="form-control" value="" required="required"/>
                    </td>
                  </tr>
                  <tr>
                    <td>
                      <input type="text" name="materiaprimna5" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="proveedor5" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="color5" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="referenciadelatela5" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="promedioporunaprenda5" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="valorunitariotela5" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="num5" value="0" onchange="calva()" onkeyup="calva()" class="form-control" value="" required="required"/>
                    </td>
                  </tr>
                  <tr>
                    <td>
                      <input type="text" name="materiaprimna6" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="proveedor6" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="color6" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="referenciadelatela6" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="promedioporunaprenda6" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="valorunitariotela6" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="num6" value="0" onchange="calva()" onkeyup="calva()" class="form-control" value="" required="required"/>
                    </td>
                  </tr>
                  <tr>
                    <td>
                      <input type="text" name="materiaprimna7" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="proveedor7" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="color7" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="referenciadelatela7" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="promedioporunaprenda7" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="valorunitariotela7" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="num7" value="0" onchange="calva()" onkeyup="calva()" class="form-control" value="" required="required"/>
                    </td>
                  </tr>
                  <tr>
                    <td>
                      <input type="text" name="materiaprimna8" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="proveedor8" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="color8" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="referenciadelatela8" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="promedioporunaprenda8" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="valorunitariotela8" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="num8" value="0" onchange="calva()" onkeyup="calva()" class="form-control" value="" required="required"/>
                    </td>
                  </tr>
                  <tr>
                    <td>
                      <input type="text" name="materiaprimna9" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="proveedor9" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="color9" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="referenciadelatela9" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="promedioporunaprenda9" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="valorunitariotela9" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="num9" value="0" onchange="calva()" onkeyup="calva()" class="form-control" value="" required="required"/>
                    </td>
                  </tr>
                  <tr>
                    <td>
                      <input type="text" name="materiaprimna10" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="proveedor10" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="color10" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="referenciadelatela10" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="promedioporunaprenda10" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="valorunitariotela10" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="num10" value="0" onchange="calva()" onkeyup="calva()" class="form-control" value="" required="required"/>
                    </td>
                  </tr>
                  <tr>
                    <td>
                      <input type="text" name="materiaprimna11" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="proveedor11" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="color11" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="referenciadelatela11" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="promedioporunaprenda11" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="valorunitariotela11" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="num11" value="0" onchange="calva()" onkeyup="calva()" class="form-control" value="" required="required"/>
                    </td>
                  </tr>
                  <tr>
                    <td>
                      <input type="text" name="materiaprimna12" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="proveedor12" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="color12" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="referenciadelatela12" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="promedioporunaprenda12" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="valorunitariotela12" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="num12" value="0" onchange="calva()" onkeyup="calva()" class="form-control" value="" required="required"/>
                    </td>
                  </tr>
                  <tr>
                    <td>
                      <input type="text" name="materiaprimna13" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="proveedor13" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="color13" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="referenciadelatela13" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="promedioporunaprenda13" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="valorunitariotela13" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="num13" value="0" onchange="calva()" onkeyup="calva()" class="form-control" value="" required="required"/>
                    </td>
                  </tr>
                  <tr>
                    <td>
                      <input type="text" name="materiaprimna14" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="proveedor14" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="color14" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="referenciadelatela14" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="promedioporunaprenda14" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="valorunitariotela14" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="num14" value="0" onchange="calva()" onkeyup="calva()" class="form-control" value="" required="required"/>
                    </td>
                  </tr>
                  <tr>
                    <td>
                      <input type="text" name="materiaprimna15" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="proveedor15" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="color15" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="referenciadelatela15" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="promedioporunaprenda15" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="valorunitariotela15" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="num15" value="0" onchange="calva()" onkeyup="calva()" class="form-control" value="" required="required"/>
                    </td>
                  </tr>
                </tbody>
              </table>
              <div class="form-group">
                <label for="nombre">
                  TOTAL MATERIA PRIMA:
                </label>
                <input type="text" name="sum" value="0" readonly="readonly" class="form-control" required="required"/>
              </div>
              <div class="form-group">
                <label for="nombre">
                  OTROS COSTOS DE PRODUCIÓN:
                </label>
                <input type="text" name="otroscostosdeproduccion" class="form-control" value="" required="required"/>
              </div>
              <table class="table table-responsive table-striped">
                <thead>
                  <tr>
                    <th>
                      <label for="nombre">
                        MATERIA PRIMA
                      </label>
                    </th>
                    <th>
                      <label for="nombre">
                        PROVEEDOR
                      </label>
                    </th>
                    <th>
                      <label for="nombre">
                        COLOR
                      </label>
                    </th>
                    <th>
                      <label for="nombre">
                        REF DE TELA
                      </label>
                    </th>
                    <th>
                      <label for="nombre">
                        PROMEDIO POR UNA PRENDA
                      </label>
                    </th>
                    <th>
                      <label for="nombre">
                        VALOR UNITARIO TELA
                      </label>
                    </th>
                    <th>
                      <label for="nombre">
                        VALOR TOTAL
                      </label>
                    </th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td>
                      <input type="text" name="materiaprima16" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="proveedor16" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="color16" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="referenciatela16" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="promedioporunaprenda16" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="valorunitariodelatela16" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="num16" value="0" onchange="calva()" onkeyup="calva()" class="form-control" value="" required="required"/>
                    </td>
                  </tr>
                  <tr>
                    <td>
                      <input type="text" name="materiaprima17" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="proveedor17" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="color17" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="referenciatela17" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="promedioporunaprenda17" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="valorunitariodelatela17" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="num17" value="0" onchange="calva()" onkeyup="calva()" class="form-control" value="" required="required"/>
                    </td>
                  </tr>
                  <tr>
                    <td>
                      <input type="text" name="materiaprima18" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="proveedor18" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="color18" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="referenciatela18" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="promedioporunaprenda18" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="valorunitariodelatela18" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="num18" value="0" onchange="calva()" onkeyup="calva()" class="form-control" value="" required="required"/>
                    </td>
                  </tr>
                  <tr>
                    <td>
                      <input type="text" name="materiaprima19" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="proveedor19" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="color19" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="referenciatela19" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="promedioporunaprenda19" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="valorunitariodelatela19" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="num19" value="0" onchange="calva()" onkeyup="calva()" class="form-control" value="" required="required"/>
                    </td>
                  </tr>
                  <tr>
                    <td>
                      <input type="text" name="materiaprima20" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="proveedor20" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="color20" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="referenciatela20" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="promedioporunaprenda20" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="valorunitariodelatela20" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="num20" value="0" onchange="calva()" onkeyup="calva()" class="form-control" value="" required="required"/>
                    </td>
                  </tr>
                  <tr>
                    <td>
                      <input type="text" name="materiaprima21" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="proveedor21" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="color21" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="referenciatela21" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="promedioporunaprenda21" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="valorunitariodelatela21" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="num21" value="0" onchange="calva()" onkeyup="calva()" class="form-control" value="" required="required"/>
                    </td>
                  </tr>
                  <tr>
                    <td>
                      <input type="text" name="materiaprima22" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="proveedor22" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="color22" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="referenciatela22" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="promedioporunaprenda22" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="valorunitariodelatela22" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="num22" value="0" onchange="calva()" onkeyup="calva()" class="form-control" value="" required="required"/>
                    </td>
                  </tr>
                  <tr>
                    <td>
                      <input type="text" name="materiaprima23" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="proveedor23" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="color23" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="referenciatela23" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="promedioporunaprenda23" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="valorunitariodelatela23" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="num23" value="0" onchange="calva()" onkeyup="calva()" class="form-control" value="" required="required"/>
                    </td>
                  </tr>
                  <tr>
                    <td>
                      <input type="text" name="materiaprima24" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="proveedor24" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="color24" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="referenciatela24" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="promedioporunaprenda24" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="valorunitariodelatela24" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="num24" value="0" onchange="calva()" onkeyup="calva()" class="form-control" value="" required="required"/>
                    </td>
                  </tr>
                  <tr>
                    <td>
                      <input type="text" name="materiaprima25" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="proveedor25" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="color25" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="referenciatela25" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="promedioporunaprenda25" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="valorunitariodelatela25" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="num25" value="0" onchange="calva()" onkeyup="calva()" class="form-control" value="" required="required"/>
                    </td>
                  </tr>
                  <tr>
                    <td>
                      <input type="text" name="materiaprima26" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="proveedor26" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="color26" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="referenciatela26" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="promedioporunaprenda26" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="valorunitariodelatela26" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="num26" value="0" onchange="calva()" onkeyup="calva()" class="form-control" value="" required="required"/>
                    </td>
                  </tr>
                  <tr>
                    <td>
                      <input type="text" name="materiaprima27" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="proveedor27" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="color27" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="referenciatela27" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="promedioporunaprenda27" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="valorunitariodelatela27" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="num27" value="0" onchange="calva()" onkeyup="calva()" class="form-control" value="" required="required"/>
                    </td>
                  </tr>
                  <tr>
                    <td>
                      <input type="text" name="materiaprima28" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="proveedor28" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="color28" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="referenciatela28" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="promedioporunaprenda28" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="valorunitariodelatela28" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="num28" value="0" onchange="calva()" onkeyup="calva()" class="form-control" value="" required="required"/>
                    </td>
                  </tr>
                  <tr>
                    <td>
                      <input type="text" name="materiaprima29" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="proveedor29" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="color29" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="referenciatela29" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="promedioporunaprenda29" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="valorunitariodelatela29" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="num29" value="0" onchange="calva()" onkeyup="calva()" class="form-control" value="" required="required"/>
                    </td>
                  </tr>
                  <tr>
                    <td>
                      <input type="text" name="materiaprima30" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="proveedor30" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="color30" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="referenciatela30" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="promedioporunaprenda30" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="valorunitariodelatela30" class="form-control" value="" required="required"/>
                    </td>
                    <td>
                      <input type="text" name="num30" value="0" onchange="calva()" onkeyup="calva()" class="form-control" value="" required="required"/>
                    </td>
                  </tr>
                </tbody>
              </table>
              <div class="form-group">
                <label for="nombre">
                  TOTAL OTROS COSTOS DE PRODUCIÓN:
                </label>
                <input type="text" name="sumneg" value="0" readonly="readonly" class="form-control" required="required"/>
              </div>
              <div class="form-group">
                <label for="nombre">
                  COSTOS INDIRECTOS DE FABRICACIÓN:
                </label>
                <input type="text" name="cosotsdeproduccion" class="form-control" value="" required="required"/>
              </div>
              <div class="form-group">
                <label for="descripción">
                  OBSERVACIÓN:
                </label>
                <textarea class="form-control" name="observacion" required="required"></textarea>
              </div>
              <div class="form-group">
                <label for="nombre">
                  SUBTOTALES MATERIALES:
                </label>
                <input type="text" name="num31" value="0" onchange="calva()" onkeyup="calva()" class="form-control" value="" required="required"/>
              </div>
              <div class="form-group">
                <label for="nombre">
                  TALLAS: UNICA
                </label>
                <label for="nombre">
                      SUBTOTAL COSTOS PCCIÓN:
                </label>
                <input type="text" name="num32" value="0" onchange="calva()" onkeyup="calva()" class="form-control" value="" required="required"/>
              </div>
              <div class="form-group">
                <label for="nombre">
                  COMPOSICIÓN:
                </label>
                <input type="text" name="composicion" class="form-control" value="" required="required"/>
                <label for="nombre">
                  MARGEN DE SEGURIDAD:
                </label>
                <input type="text" name="num33" value="0" onchange="calva()" onkeyup="calva()" class="form-control" value="" required="required"/>
                <label for="nombre">
                  SUBTOTAL:
                </label>
                <input type="text" name="sumval" value="0" readonly="readonly" class="form-control" required="required"/>
              </div>
              <div class="form-group">
                <label for="nombre">
                  ELABORO:
                </label>
                <label for="nombre">
                  COSTOS INDIRECTOS:
                </label>
                <input type="text" name="num34" value="0" onchange="calva()" onkeyup="calva()" class="form-control" value="" required="required"/>
              </div>
              <div class="form-group">
                <label for="nombre">
                  VALOR EN FABRICA:
                </label>
                <input type="text" name="sumfabr" value="0" readonly="readonly" class="form-control" required="required"/>
              </div>
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-default" data-dismiss="modal" style="height: 34px; border-radius: 4px; box-shadow: 5px 5px #888888; margin-right: 20px;">
                CERRAR
              </button>
              <input type="submit" name="GuardarHojaDeCostos" value="GUARDAR HOJA DE COSTOS" id="EtiGuar" style="height: 34px; border-radius: 4px; box-shadow: 5px 5px #888888;"/>
            </div>
          </form>
        </div>
      </div>
    </div>
    <script src="Js/Jqu.min.js"></script>
    <script src="Js/Boot.min.js"></script>
    <script>
      function calva() {
        try {
          var a = parseInt(document.f.num1.value),
              b = parseInt(document.f.num2.value);
              c = parseInt(document.f.num3.value);
              d = parseInt(document.f.num4.value);
              e = parseInt(document.f.num5.value);
              f = parseInt(document.f.num6.value);
              g = parseInt(document.f.num7.value);
              h = parseInt(document.f.num8.value);
              i = parseInt(document.f.num9.value);
              j = parseInt(document.f.num10.value);
              k = parseInt(document.f.num11.value);
              l = parseInt(document.f.num12.value);
              m = parseInt(document.f.num13.value);
              n = parseInt(document.f.num14.value);
              ñ = parseInt(document.f.num15.value);
          document.f.sum.value = a + b + c + d + e + f + g + h + i + j + k + l + m + n + ñ;
        } catch (e) {
        }
        try {
          var o = parseInt(document.f.num16.value),
              p = parseInt(document.f.num17.value);
              q = parseInt(document.f.num18.value);
              r = parseInt(document.f.num19.value);
              s = parseInt(document.f.num20.value);
              t = parseInt(document.f.num21.value);
              u = parseInt(document.f.num22.value);
              v = parseInt(document.f.num23.value);
              w = parseInt(document.f.num24.value);
              x = parseInt(document.f.num25.value);
              y = parseInt(document.f.num26.value);
              z = parseInt(document.f.num27.value);
              ch = parseInt(document.f.num28.value);
              ll = parseInt(document.f.num29.value);
              rr = parseInt(document.f.num30.value);
          document.f.sumneg.value = o + p + q + r + s + t + u + v + w + x + y + z + ch + ll + rr;
        } catch (e) {
        }
        try {
          var a1 = parseInt(document.f.num31.value),
              b1 = parseInt(document.f.num32.value);
              c1 = parseInt(document.f.num33.value);
          document.f.sumval.value = a1 + b1 + c1;
        } catch (e) {
        }
        try {
          var d1 = parseInt(document.f.sumval.value),
              e1 = parseInt(document.f.num34.value);
          document.f.sumfabr.value = d1 + e1;
        } catch (e) {
        }
      }
   </script>
  </body>
  </html>
  <?php
  if(isset($_POST['GuardarHojaDeCostos'])){
    $post_IdPrincipal = $_POST['IdPrincipal'];
    $Post_hojadecostosnum = $_POST['hojadecostosnum'];
    $Post_idreferencia = $_POST['idreferencia'];
    $Post_descripcion = $_POST['descripcion'];
    $Post_coleccion = $_POST['coleccion'];
    $Post_hojadecorte = $_POST['hojadecorte'];
    $FechaDeIngreso = $_POST['FechaDeIngreso'];
    $FechaDeIngreso = str_replace("T"," ",$FechaDeIngreso);
    $FechaDeIngreso = $FechaDeIngreso.":00";
    $FechaDeIngreso = ($FechaDeIngreso=="")?(null):($FechaDeIngreso);
    function check_schedule1($FechaDeIngreso){
      date_default_timezone_set('America/Bogota');
      $today1 = date('Y-m-d H:i:s');
      if($FechaDeIngreso > $today1){
        return false;
      }
      else{
        return true;
      }
    }
    $Post_materiaprimna1 = $_POST['materiaprimna1'];
    $Post_materiaprimna2 = $_POST['materiaprimna2'];
    $Post_materiaprimna3 = $_POST['materiaprimna3'];
    $Post_materiaprimna4 = $_POST['materiaprimna4'];
    $Post_materiaprimna5 = $_POST['materiaprimna5'];
    $Post_materiaprimna6 = $_POST['materiaprimna6'];
    $Post_materiaprimna7 = $_POST['materiaprimna7'];
    $Post_materiaprimna8 = $_POST['materiaprimna8'];
    $Post_materiaprimna9 = $_POST['materiaprimna9'];
    $Post_materiaprimna10 = $_POST['materiaprimna10'];
    $Post_materiaprimna11 = $_POST['materiaprimna11'];
    $Post_materiaprimna12 = $_POST['materiaprimna12'];
    $Post_materiaprimna13 = $_POST['materiaprimna13'];
    $Post_materiaprimna14 = $_POST['materiaprimna14'];
    $Post_materiaprimna15 = $_POST['materiaprimna15'];
    $Post_proveedor1 = $_POST['proveedor1'];
    $Post_proveedor2 = $_POST['proveedor2'];
    $Post_proveedor3 = $_POST['proveedor3'];
    $Post_proveedor4 = $_POST['proveedor4'];
    $Post_proveedor5 = $_POST['proveedor5'];
    $Post_proveedor6 = $_POST['proveedor6'];
    $Post_proveedor7 = $_POST['proveedor7'];
    $Post_proveedor8 = $_POST['proveedor8'];
    $Post_proveedor9 = $_POST['proveedor9'];
    $Post_proveedor10 = $_POST['proveedor10'];
    $Post_proveedor11 = $_POST['proveedor11'];
    $Post_proveedor12 = $_POST['proveedor12'];
    $Post_proveedor13 = $_POST['proveedor13'];
    $Post_proveedor14 = $_POST['proveedor14'];
    $Post_proveedor15 = $_POST['proveedor15'];
    $Post_color1 = $_POST['color1'];
    $Post_color2 = $_POST['color2'];
    $Post_color3 = $_POST['color3'];
    $Post_color4 = $_POST['color4'];
    $Post_color5 = $_POST['color5'];
    $Post_color6 = $_POST['color6'];
    $Post_color7 = $_POST['color7'];
    $Post_color8 = $_POST['color8'];
    $Post_color9 = $_POST['color9'];
    $Post_color10 = $_POST['color10'];
    $Post_color11 = $_POST['color11'];
    $Post_color12 = $_POST['color12'];
    $Post_color13 = $_POST['color13'];
    $Post_color14 = $_POST['color14'];
    $Post_color15 = $_POST['color15'];
    $Post_referenciadelatela1 = $_POST['referenciadelatela1'];
    $Post_referenciadelatela2 = $_POST['referenciadelatela2'];
    $Post_referenciadelatela3 = $_POST['referenciadelatela3'];
    $Post_referenciadelatela4 = $_POST['referenciadelatela4'];
    $Post_referenciadelatela5 = $_POST['referenciadelatela5'];
    $Post_referenciadelatela6 = $_POST['referenciadelatela6'];
    $Post_referenciadelatela7 = $_POST['referenciadelatela7'];
    $Post_referenciadelatela8 = $_POST['referenciadelatela8'];
    $Post_referenciadelatela9 = $_POST['referenciadelatela9'];
    $Post_referenciadelatela10 = $_POST['referenciadelatela10'];
    $Post_referenciadelatela11 = $_POST['referenciadelatela11'];
    $Post_referenciadelatela12 = $_POST['referenciadelatela12'];
    $Post_referenciadelatela13 = $_POST['referenciadelatela13'];
    $Post_referenciadelatela14 = $_POST['referenciadelatela14'];
    $Post_referenciadelatela15 = $_POST['referenciadelatela15'];
    $Post_promedioporunaprenda1 = $_POST['promedioporunaprenda1'];
    $Post_promedioporunaprenda2 = $_POST['promedioporunaprenda2'];
    $Post_promedioporunaprenda3 = $_POST['promedioporunaprenda3'];
    $Post_promedioporunaprenda4 = $_POST['promedioporunaprenda4'];
    $Post_promedioporunaprenda5 = $_POST['promedioporunaprenda5'];
    $Post_promedioporunaprenda6 = $_POST['promedioporunaprenda6'];
    $Post_promedioporunaprenda7 = $_POST['promedioporunaprenda7'];
    $Post_promedioporunaprenda8 = $_POST['promedioporunaprenda8'];
    $Post_promedioporunaprenda9 = $_POST['promedioporunaprenda9'];
    $Post_promedioporunaprenda10 = $_POST['promedioporunaprenda10'];
    $Post_promedioporunaprenda11 = $_POST['promedioporunaprenda11'];
    $Post_promedioporunaprenda12 = $_POST['promedioporunaprenda12'];
    $Post_promedioporunaprenda13 = $_POST['promedioporunaprenda13'];
    $Post_promedioporunaprenda14 = $_POST['promedioporunaprenda14'];
    $Post_promedioporunaprenda15 = $_POST['promedioporunaprenda15'];
    $Post_valorunitariotela1 = $_POST['valorunitariotela1'];
    $Post_valorunitariotela2 = $_POST['valorunitariotela2'];
    $Post_valorunitariotela3 = $_POST['valorunitariotela3'];
    $Post_valorunitariotela4 = $_POST['valorunitariotela4'];
    $Post_valorunitariotela5 = $_POST['valorunitariotela5'];
    $Post_valorunitariotela6 = $_POST['valorunitariotela6'];
    $Post_valorunitariotela7 = $_POST['valorunitariotela7'];
    $Post_valorunitariotela8 = $_POST['valorunitariotela8'];
    $Post_valorunitariotela9 = $_POST['valorunitariotela9'];
    $Post_valorunitariotela10 = $_POST['valorunitariotela10'];
    $Post_valorunitariotela11 = $_POST['valorunitariotela11'];
    $Post_valorunitariotela12 = $_POST['valorunitariotela12'];
    $Post_valorunitariotela13 = $_POST['valorunitariotela13'];
    $Post_valorunitariotela14 = $_POST['valorunitariotela14'];
    $Post_valorunitariotela15 = $_POST['valorunitariotela15'];
    $Post_num1 = $_POST['num1'];
    $Post_num2 = $_POST['num2'];
    $Post_num3= $_POST['num3'];
    $Post_num4 = $_POST['num4'];
    $Post_num5 = $_POST['num5'];
    $Post_num6 = $_POST['num6'];
    $Post_num7 = $_POST['num7'];
    $Post_num8 = $_POST['num8'];
    $Post_num9 = $_POST['num9'];
    $Post_num10 = $_POST['num10'];
    $Post_num11 = $_POST['num11'];
    $Post_num12 = $_POST['num12'];
    $Post_num13 = $_POST['num13'];
    $Post_num14 = $_POST['num14'];
    $Post_num15 = $_POST['num15'];
    $Post_sum = $_POST['sum'];
    $Post_otroscostosdeproduccion = $_POST['otroscostosdeproduccion'];
    $Post_materiaprima16 = $_POST['materiaprima16'];
    $Post_materiaprima17 = $_POST['materiaprima17'];
    $Post_materiaprima18 = $_POST['materiaprima18'];
    $Post_materiaprima19 = $_POST['materiaprima19'];
    $Post_materiaprima20= $_POST['materiaprima20'];
    $Post_materiaprima21 = $_POST['materiaprima21'];
    $Post_materiaprima22 = $_POST['materiaprima22'];
    $Post_materiaprima23 = $_POST['materiaprima23'];
    $Post_materiaprima24 = $_POST['materiaprima24'];
    $Post_materiaprima25 = $_POST['materiaprima25'];
    $Post_materiaprima26 = $_POST['materiaprima26'];
    $Post_materiaprima27 = $_POST['materiaprima27'];
    $Post_materiaprima28 = $_POST['materiaprima28'];
    $Post_materiaprima29 = $_POST['materiaprima29'];
    $Post_materiaprima30 = $_POST['materiaprima30'];
    $Post_proveedor16 = $_POST['proveedor16'];
    $Post_proveedor17 = $_POST['proveedor17'];
    $Post_proveedor18 = $_POST['proveedor18'];
    $Post_proveedor19 = $_POST['proveedor19'];
    $Post_proveedor20 = $_POST['proveedor20'];
    $Post_proveedor21 = $_POST['proveedor21'];
    $Post_proveedor22 = $_POST['proveedor22'];
    $Post_proveedor23 = $_POST['proveedor23'];
    $Post_proveedor24 = $_POST['proveedor24'];
    $Post_proveedor25 = $_POST['proveedor25'];
    $Post_proveedor26 = $_POST['proveedor26'];
    $Post_proveedor27 = $_POST['proveedor27'];
    $Post_proveedor28 = $_POST['proveedor28'];
    $Post_proveedor29 = $_POST['proveedor29'];
    $Post_proveedor30= $_POST['proveedor30'];
    $Post_color16 = $_POST['color16'];
    $Post_color17 = $_POST['color17'];
    $Post_color18 = $_POST['color18'];
    $Post_color19 = $_POST['color19'];
    $Post_color20 = $_POST['color20'];
    $Post_color21 = $_POST['color21'];
    $Post_color22 = $_POST['color22'];
    $Post_color23 = $_POST['color23'];
    $Post_color24 = $_POST['color24'];
    $Post_color25 = $_POST['color25'];
    $Post_color26 = $_POST['color26'];
    $Post_color27 = $_POST['color27'];
    $Post_color28 = $_POST['color28'];
    $Post_color29 = $_POST['color29'];
    $Post_color30 = $_POST['color30'];
    $Post_referenciatela16 = $_POST['referenciatela16'];
    $Post_referenciatela17 = $_POST['referenciatela17'];
    $Post_referenciatela18 = $_POST['referenciatela18'];
    $Post_referenciatela19 = $_POST['referenciatela19'];
    $Post_referenciatela20 = $_POST['referenciatela20'];
    $Post_referenciatela21 = $_POST['referenciatela21'];
    $Post_referenciatela22 = $_POST['referenciatela22'];
    $Post_referenciatela23 = $_POST['referenciatela23'];
    $Post_referenciatela24 = $_POST['referenciatela24'];
    $Post_referenciatela25 = $_POST['referenciatela25'];
    $Post_referenciatela26 = $_POST['referenciatela26'];
    $Post_referenciatela27 = $_POST['referenciatela27'];
    $Post_referenciatela28 = $_POST['referenciatela28'];
    $Post_referenciatela29 = $_POST['referenciatela29'];
    $Post_referenciatela30 = $_POST['referenciatela30'];
    $Post_promedioporunaprenda16 = $_POST['promedioporunaprenda16'];
    $Post_promedioporunaprenda17 = $_POST['promedioporunaprenda17'];
    $Post_promedioporunaprenda18 = $_POST['promedioporunaprenda18'];
    $Post_promedioporunaprenda19 = $_POST['promedioporunaprenda19'];
    $Post_promedioporunaprenda20 = $_POST['promedioporunaprenda20'];
    $Post_promedioporunaprenda21 = $_POST['promedioporunaprenda21'];
    $Post_promedioporunaprenda22 = $_POST['promedioporunaprenda22'];
    $Post_promedioporunaprenda23 = $_POST['promedioporunaprenda23'];
    $Post_promedioporunaprenda24 = $_POST['promedioporunaprenda24'];
    $Post_promedioporunaprenda25 = $_POST['promedioporunaprenda25'];
    $Post_promedioporunaprenda26 = $_POST['promedioporunaprenda26'];
    $Post_promedioporunaprenda27 = $_POST['promedioporunaprenda27'];
    $Post_promedioporunaprenda28 = $_POST['promedioporunaprenda28'];
    $Post_promedioporunaprenda29 = $_POST['promedioporunaprenda29'];
    $Post_promedioporunaprenda30 = $_POST['promedioporunaprenda30'];
    $Post_valorunitariodelatela16 = $_POST['valorunitariodelatela16'];
    $Post_valorunitariodelatela17 = $_POST['valorunitariodelatela17'];
    $Post_valorunitariodelatela18 = $_POST['valorunitariodelatela18'];
    $Post_valorunitariodelatela19 = $_POST['valorunitariodelatela19'];
    $Post_valorunitariodelatela20 = $_POST['valorunitariodelatela20'];
    $Post_valorunitariodelatela21 = $_POST['valorunitariodelatela21'];
    $Post_valorunitariodelatela22 = $_POST['valorunitariodelatela22'];
    $Post_valorunitariodelatela23 = $_POST['valorunitariodelatela23'];
    $Post_valorunitariodelatela24 = $_POST['valorunitariodelatela24'];
    $Post_valorunitariodelatela25 = $_POST['valorunitariodelatela25'];
    $Post_valorunitariodelatela26 = $_POST['valorunitariodelatela26'];
    $Post_valorunitariodelatela27 = $_POST['valorunitariodelatela27'];
    $Post_valorunitariodelatela28 = $_POST['valorunitariodelatela28'];
    $Post_valorunitariodelatela29 = $_POST['valorunitariodelatela29'];
    $Post_valorunitariodelatela30 = $_POST['valorunitariodelatela30'];
    $Post_num16 = $_POST['num16'];
    $Post_num17 = $_POST['num17'];
    $Post_num18 = $_POST['num18'];
    $Post_num19 = $_POST['num19'];
    $Post_num20 = $_POST['num20'];
    $Post_num21 = $_POST['num21'];
    $Post_num22 = $_POST['num22'];
    $Post_num23 = $_POST['num23'];
    $Post_num24 = $_POST['num24'];
    $Post_num25 = $_POST['num25'];
    $Post_num26 = $_POST['num26'];
    $Post_num27 = $_POST['num27'];
    $Post_num28 = $_POST['num28'];
    $Post_num29 = $_POST['num29'];
    $Post_num30 = $_POST['num30'];
    $Post_sumneg = $_POST['sumneg'];
    $Post_cosotsdeproduccion = $_POST['cosotsdeproduccion'];
    $Post_observacion = $_POST['observacion'];
    $Post_num31 = $_POST['num31'];
    $Post_num32 = $_POST['num32'];
    $Post_composicion = $_POST['composicion'];
    $Post_num33 = $_POST['num33'];
    $Post_sumval = $_POST['sumval'];
    $Post_num34 = $_POST['num34'];
    $Post_sumfabr = $_POST['sumfabr'];
    mysqli_query($mysqli, "SET NAMES utf8");
    $Insert_Post = mysqli_query($mysqli, "INSERT INTO hojadecostos (id,hojadecostosnum,idreferencia,descripcion,coleccion,hojadecorte,FechaDeIngreso,materiaprimna1,materiaprimna2,materiaprimna3,materiaprimna4,materiaprimna5,materiaprimna6,materiaprimna7,materiaprimna8,materiaprimna9,materiaprimna10,materiaprimna11,materiaprimna12,materiaprimna13,materiaprimna14,materiaprimna15,proveedor1,proveedor2,proveedor3,proveedor4,proveedor5,proveedor6,proveedor7,proveedor8,proveedor9,proveedor10,proveedor11,proveedor12,proveedor13,proveedor14,proveedor15,color1,color2,color3,color4,color5,color6,color7,color8,color9,color10,color11,color12,color13,color14,color15,referenciadelatela1,referenciadelatela2,referenciadelatela3,referenciadelatela4,referenciadelatela5,referenciadelatela6,referenciadelatela7,referenciadelatela8,referenciadelatela9,referenciadelatela10,referenciadelatela11,referenciadelatela12,referenciadelatela13,referenciadelatela14,referenciadelatela15,promedioporunaprenda1,promedioporunaprenda2,promedioporunaprenda3,promedioporunaprenda4,promedioporunaprenda5,promedioporunaprenda6,promedioporunaprenda7,promedioporunaprenda8,promedioporunaprenda9,promedioporunaprenda10,promedioporunaprenda11,promedioporunaprenda12,promedioporunaprenda13,promedioporunaprenda14,promedioporunaprenda15,valorunitariotela1,valorunitariotela2,valorunitariotela3,valorunitariotela4,valorunitariotela5,valorunitariotela6,valorunitariotela7,valorunitariotela8,valorunitariotela9,valorunitariotela10,valorunitariotela11,valorunitariotela12,valorunitariotela13,valorunitariotela14,valorunitariotela15,num1,num2,num3,num4,num5,num6,num7,num8,num9,num10,num11,num12,num13,num14,num15,sum,otroscostosdeproduccion,materiaprima16,materiaprima17,materiaprima18,materiaprima19,materiaprima20,materiaprima21,materiaprima22,materiaprima23,materiaprima24,materiaprima25,materiaprima26,materiaprima27,materiaprima28,materiaprima29,materiaprima30,proveedor16,proveedor17,proveedor18,proveedor19,proveedor20,proveedor21,proveedor22,proveedor23,proveedor24,proveedor25,proveedor26,proveedor27,proveedor28,proveedor29,proveedor30,color16,color17,color18,color19,color20,color21,color22,color23,color24,color25,color26,color27,color28,color29,color30,referenciatela16,referenciatela17,referenciatela18,referenciatela19,referenciatela20,referenciatela21,referenciatela22,referenciatela23,referenciatela24,referenciatela25,referenciatela26,referenciatela27,referenciatela28,referenciatela29,referenciatela30,promedioporunaprenda16,promedioporunaprenda17,promedioporunaprenda18,promedioporunaprenda19,promedioporunaprenda20,promedioporunaprenda21,promedioporunaprenda22,promedioporunaprenda23,promedioporunaprenda24,promedioporunaprenda25,promedioporunaprenda26,promedioporunaprenda27,promedioporunaprenda28,promedioporunaprenda29,promedioporunaprenda30,valorunitariodelatela16,valorunitariodelatela17,valorunitariodelatela18,valorunitariodelatela19,valorunitariodelatela20,valorunitariodelatela21,valorunitariodelatela22,valorunitariodelatela23,valorunitariodelatela24,valorunitariodelatela25,valorunitariodelatela26,valorunitariodelatela27,valorunitariodelatela28,valorunitariodelatela29,valorunitariodelatela30,num16,num17,num18,num19,num20,num21,num22,num23,num24,num25,num26,num27,num28,num29,num30,sumneg,cosotsdeproduccion,observacion,num31,num32,composicion,num33,sumval,num34,sumfabr) VALUES ('$post_IdPrincipal','$Post_hojadecostosnum','$Post_idreferencia','$Post_descripcion','$Post_coleccion','$Post_hojadecorte','$FechaDeIngreso','$Post_materiaprimna1','$Post_materiaprimna2','$Post_materiaprimna3','$Post_materiaprimna4','$Post_materiaprimna5','$Post_materiaprimna6','$Post_materiaprimna7','$Post_materiaprimna8','$Post_materiaprimna9','$Post_materiaprimna10','$Post_materiaprimna11','$Post_materiaprimna12','$Post_materiaprimna13','$Post_materiaprimna14','$Post_materiaprimna15','$Post_proveedor1','$Post_proveedor2','$Post_proveedor3','$Post_proveedor4','$Post_proveedor5','$Post_proveedor6','$Post_proveedor7','$Post_proveedor8','$Post_proveedor9','$Post_proveedor10','$Post_proveedor11','$Post_proveedor12','$Post_proveedor13','$Post_proveedor14','$Post_proveedor15','$Post_color1','$Post_color2','$Post_color3','$Post_color4','$Post_color5','$Post_color6','$Post_color7','$Post_color8','$Post_color9','$Post_color10','$Post_color11','$Post_color12','$Post_color13','$Post_color14','$Post_color15','$Post_referenciadelatela1','$Post_referenciadelatela2','$Post_referenciadelatela3','$Post_referenciadelatela4','$Post_referenciadelatela5','$Post_referenciadelatela6','$Post_referenciadelatela7','$Post_referenciadelatela8','$Post_referenciadelatela9','$Post_referenciadelatela10','$Post_referenciadelatela11','$Post_referenciadelatela12','$Post_referenciadelatela13','$Post_referenciadelatela14','$Post_referenciadelatela15','$Post_promedioporunaprenda1','$Post_promedioporunaprenda2','$Post_promedioporunaprenda3','$Post_promedioporunaprenda4','$Post_promedioporunaprenda5','$Post_promedioporunaprenda6','$Post_promedioporunaprenda7','$Post_promedioporunaprenda8','$Post_promedioporunaprenda9','$Post_promedioporunaprenda10','$Post_promedioporunaprenda11','$Post_promedioporunaprenda12','$Post_promedioporunaprenda13','$Post_promedioporunaprenda14','$Post_promedioporunaprenda15','$Post_valorunitariotela1','$Post_valorunitariotela2','$Post_valorunitariotela3','$Post_valorunitariotela4','$Post_valorunitariotela5','$Post_valorunitariotela6','$Post_valorunitariotela7','$Post_valorunitariotela8','$Post_valorunitariotela9','$Post_valorunitariotela10','$Post_valorunitariotela11','$Post_valorunitariotela12','$Post_valorunitariotela13','$Post_valorunitariotela14','$Post_valorunitariotela15','$Post_num1','$Post_num2','$Post_num3','$Post_num4','$Post_num5','$Post_num6','$Post_num7','$Post_num8','$Post_num9','$Post_num10','$Post_num11','$Post_num12','$Post_num13','$Post_num14','$Post_num15','$Post_sum','$Post_otroscostosdeproduccion','$Post_materiaprima16','$Post_materiaprima17','$Post_materiaprima18','$Post_materiaprima19','$Post_materiaprima20','$Post_materiaprima21','$Post_materiaprima22','$Post_materiaprima23','$Post_materiaprima24','$Post_materiaprima25','$Post_materiaprima26','$Post_materiaprima27','$Post_materiaprima28','$Post_materiaprima29','$Post_materiaprima30','$Post_proveedor16','$Post_proveedor17','$Post_proveedor18','$Post_proveedor19','$Post_proveedor20','$Post_proveedor21','$Post_proveedor22','$Post_proveedor23','$Post_proveedor24','$Post_proveedor25','$Post_proveedor26','$Post_proveedor27','$Post_proveedor28','$Post_proveedor29','$Post_proveedor30','$Post_color16','$Post_color17','$Post_color18','$Post_color19','$Post_color20','$Post_color21','$Post_color22','$Post_color23','$Post_color24','$Post_color25','$Post_color26','$Post_color27','$Post_color28','$Post_color29','$Post_color30','$Post_referenciatela16','$Post_referenciatela17','$Post_referenciatela18','$Post_referenciatela19','$Post_referenciatela20','$Post_referenciatela21','$Post_referenciatela22','$Post_referenciatela23','$Post_referenciatela24','$Post_referenciatela25','$Post_referenciatela26','$Post_referenciatela27','$Post_referenciatela28','$Post_referenciatela29','$Post_referenciatela30','$Post_promedioporunaprenda16','$Post_promedioporunaprenda17','$Post_promedioporunaprenda18','$Post_promedioporunaprenda19','$Post_promedioporunaprenda20','$Post_promedioporunaprenda21','$Post_promedioporunaprenda22','$Post_promedioporunaprenda23','$Post_promedioporunaprenda24','$Post_promedioporunaprenda25','$Post_promedioporunaprenda26','$Post_promedioporunaprenda27','$Post_promedioporunaprenda28','$Post_promedioporunaprenda29','$Post_promedioporunaprenda30','$Post_valorunitariodelatela16','$Post_valorunitariodelatela17','$Post_valorunitariodelatela18','$Post_valorunitariodelatela19','$Post_valorunitariodelatela20','$Post_valorunitariodelatela21','$Post_valorunitariodelatela22','$Post_valorunitariodelatela23','$Post_valorunitariodelatela24','$Post_valorunitariodelatela25','$Post_valorunitariodelatela26','$Post_valorunitariodelatela27','$Post_valorunitariodelatela28','$Post_valorunitariodelatela29','$Post_valorunitariodelatela30','$Post_num16','$Post_num17','$Post_num18','$Post_num19','$Post_num20','$Post_num21','$Post_num22','$Post_num23','$Post_num24','$Post_num25','$Post_num26','$Post_num27','$Post_num28','$Post_num29','$Post_num30','$Post_sumneg','$Post_cosotsdeproduccion','$Post_observacion','$Post_num31','$Post_num32','$Post_composicion','$Post_num33','$Post_sumval','$Post_num3','$Post_sumfabr')") or die (mysqli_error($mysqli));
      echo "<script>alert('HOJA DE COSTO AGREGADA CON EXITO!!!')</script>";
      echo "<script>window.open('HojaDeCostos.php','_self')</script>";
    }
    ?>
<?php } ?>