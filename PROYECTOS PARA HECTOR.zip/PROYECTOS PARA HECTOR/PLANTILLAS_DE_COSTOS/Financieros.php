<?php
include("Conn/conn.php");
error_reporting(E_ALL ^ E_NOTICE);
session_start();
if(!isset($_SESSION['user_name'])){
  echo "<script>alert('NO TIENES ACCESO AL ADMINISTRADOR !!!')</script>";
  echo "<script>window.open('login.php','_self')</script>";
}
else{ ?>
  <!DOCTYPE html>
  <html lang="es">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Financieros</title>
    <link rel="icon" type="image/png" href="../img/icon/1.png">
    <link rel="stylesheet" href="Css/Boot.min.css">
    <link rel="stylesheet" href="Css/Esti.css">
  </head>
  <body>
    <nav class="navbar navbar-default">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">
              Toggle navigation
            </span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="index.php">
            Financieros
          </a>
        </div>
        <div id="navbar" class="collapse navbar-collapse">
          <ul class="nav navbar-nav">
            <li>
              <a href="index.php">
                Panel de Control
              </a>
            </li>
            <li class="active">
              <a href="paginas.php">
                Páginas
              </a>
            </li>
            <li>
              <a href="usuarios.php">
                Usuarios
              </a>
            </li>
          </ul>
          <ul class="nav navbar-nav navbar-right">
            <li>
              <a href="index.php">
                Bienvenido, Financieros
              </a>
            </li>
            <li>
              <a href="logout.php">
                Salir
              </a>
            </li>
          </ul>
        </div>
      </div>
    </nav>
    <header id="header">
      <div class="container">
        <div class="row">
          <div class="col-md-10">
            <h1>
              <span class="glyphicon glyphicon-cog" aria-hidden="true"></span>
                Páginas
              <small>
                Administrar Los Financieros
              </small>
            </h1>
          </div>
          <div class="col-md-2">
            <div class="dropdown crear">
              <button class="btn btn-default dropdown-toggle" type="button" id="dropdownMenu1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
                Crear Contenido
                <span class="caret"></span>
              </button>
              <ul class="dropdown-menu" aria-labelledby="dropdownMenu1">
                <li>
                  <a type="button" data-toggle="modal" data-target="#addPage">
                    Agregar Un Nuevo Financiero
                  </a>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </header>
    <section id="breadcrumb">
      <div class="container">
        <ol class="breadcrumb">
          <li>
            <a href="index.php">
              Panel de Control
            </a>
          </li>
          <li>
            Páginas
          </li>
          <li class="active">
            Ver Financieros
          </li>
        </ol>
      </div>
    </section>
    <section id="main">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <div class="panel panel-default">
              <div class="panel-heading main-color-bg">
                <h3 class="panel-title">
                  NOMBRE DEL ESTABLECIMIENTO
                </h3>
              </div>
              <div class="panel-body table-responsive">
                <table class="table table-striped table-hover">
                  <tr>
                    <th>
                      REFERENCIA:
                    </th>
                    <th>
                      PRODUCTO:
                    </th>
                    <th>
                      PVP / USD:
                    </th>
                    <th>
                      TRANSPORTE INTERNACIONAL:
                    </th>
                    <th>
                      TOTAL:
                    </th>
                    <th>
                      COMISION PAGINA %:
                    </th>
                    <th>
                      COMOSION PASARELA %:
                    </th>
                    <th>
                      COMISION PAYPAL %:
                    </th>
                    <th>
                      TOTAL COMISION:
                    </th>
                    <th>
                      TRM DEL DÍA VALOR:
                    </th>
                    <th>
                      TRM DEL DÍA VALOR:
                    </th>
                    <th>
                      COMISION BANCO:
                    </th>
                    <th>
                      TOTAL DESCUENTO:
                    </th>
                  </tr>
                  <?php
                  mysqli_set_charset($mysqli, 'utf8');
                  $get_posts = "SELECT * FROM financieros ORDER BY idreferencia DESC";
                  $run_posts = mysqli_query($mysqli, $get_posts);
                  while ($row_posts = mysqli_fetch_array($run_posts)) {
                    $Post_Referencia = $row_posts['idreferencia'];
                    $Post_Producto = $row_posts['producto'];
                    $Post_Pvp_Usd = $row_posts['pvpusd'];
                    $Post_Transporte_Internacional = $row_posts['transporte'];
                    $Post_Total = $row_posts['total'];
                    $Post_Comision_Por_Pagina = $row_posts['comisionporpagina'];
                    $Post_Comision_Por_Pasarela = $row_posts['comisionporpasarela'];
                    $Post_Comision_Paypal = $row_posts['comisionpaypal'];
                    $Post_Total_Comision = $row_posts['totalcomision'];
                    $Post_Trm_Del_Dia_Valor = $row_posts['trmdeldiavalor'];
                    $Post_Comision_Banco = $row_posts['comisionbanco'];
                    $Post_Total_Descuento = $row_posts['totaldescuento'];
                    ?>
                    <tr>
                      <td>
                        <?php echo $Post_Referencia; ?>
                      </td>
                      <td>
                        <?php echo $Post_Producto; ?>
                      </td>
                      <td>
                        <?php echo $Post_Pvp_Usd; ?>
                      </td>
                      <td>
                        <?php echo $Post_Transporte_Internacional; ?>
                      </td>
                      <td>
                        <?php echo $Post_Total; ?>
                      </td>
                      <td>
                        <?php echo $Post_Comision_Por_Pagina; ?>
                      </td>
                      <td>
                        <?php echo $Post_Comision_Por_Pasarela; ?>
                      </td>
                      <td>
                        <?php echo $Post_Comision_Paypal; ?>
                      </td>
                      <td>
                        <?php echo $Post_Total_Comision; ?>
                      </td>
                      <td>
                        <?php echo $Post_Trm_Del_Dia_Valor; ?>
                      </td>
                      <td>
                        <?php echo $Post_Comision_Banco; ?>
                      </td>
                      <td>
                        <?php echo $Post_Total_Descuento; ?>
                      </td>
                    </tr>
                  <?php } ?>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <footer id="footer">
      <p>
        Powered By Imaginaudio Digital, &copy; 2020
      </p>
    </footer>
    <div class="modal fade" id="addPage" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <form name="f" action="" method="post" enctype="multipart/form-data" target="_blank" >
            <div class="modal-header">
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">
                  &times;
                </span>
              </button>
              <h4 class="modal-title" id="myModalLabel">
                Agregar Financieros
              </h4>
            </div>
            <div class="panel-body table-responsive">
              <div class="form-group">
                <label for="nombre">
                  ID PRINCIPAL:
                </label>
                <input type="text" name="IdPrincipal" class="form-control" value="" required="required"/>
              </div>
              <div class="form-group">
                <label for="nombre">
                  REFERENCIA:
                </label>
                <input type="text" name="idreferencia" class="form-control" value="" required="required"/>
              </div>
              <div class="form-group">
                <label for="nombre">
                      PRODUCTO:
                </label>
                <input type="text" name="producto" class="form-control" value="" required="required"/>
              </div>
              <div class="form-group">
                <label for="nombre">
                  PVP / USD:
                </label>
                <input type="text" name="pvpusd" class="form-control" value="" required="required"/>
              </div>
              <div class="form-group">
                <label for="nombre">
                  TRANSPORTE INTERNACIONAL:
                </label>
                <input type="text" name="transporteinternacional" class="form-control" value="" required="required"/>
              </div>
              <div class="form-group">
                <label for="nombre">
                  TOTAL:
                </label>
                <input type="text" name="num1" value="0" onchange="calva()" onkeyup="calva()" class="form-control" value="" required="required"/>
              </div>
              <div class="form-group">
                <label for="nombre">
                  COMISION PAGINA %:
                </label>
                <input type="text" name="num2" value="1" readonly="readonly" onchange="calva()" onkeyup="calva()" class="form-control" value="" required="required"/>
              </div>
              <div class="form-group">
                <label for="nombre">
                  COMISION PAGINA:
                </label>
                <input type="text" name="sum" value="0" readonly="readonly" class="form-control" required="required"/>
              </div>
              <div class="form-group">
                <label for="autores">
                  COMOSION PASARELA %:
                </label>
                <input type="text" name="num3" value="35" readonly="readonly" onchange="calva()" onkeyup="calva()" class="form-control" value="" required="required"/>
              </div>
              <div class="form-group">
                <label for="autores">
                  COMOSION PASARELA:
                </label>
                <input type="text" name="sumban" value="0" readonly="readonly" class="form-control" required="required"/>
              </div>
              <div class="form-group">
                <label for="autores">
                  COMISION PAYPAL %:
                </label>
                <input type="text" name="num4" value="6" readonly="readonly" onchange="calva()" onkeyup="calva()" class="form-control" required="required"/>
              </div>
              <div class="form-group">
                <label for="autores">
                  COMISION PAYPAL:
                </label>
                <input type="text" name="sumpay" value="0" readonly="readonly" class="form-control" required="required"/>
              </div>
              <div class="form-group">
                <label for="autores">
                  TOTAL COMISION:
                </label>
                <input type="text" name="sumtot" value="0" readonly="readonly" class="form-control" required="required"/>
              </div>
              <div class="form-group">
                <label for="autores">
                  TRM DEL DÍA VALOR:
                </label>
                <input type="text" name="num5" value="3950" readonly="readonly" onchange="calva()" onkeyup="calva()" class="form-control" required="required"/>
              </div>
              <div class="form-group">
                <label for="autores">
                  TRM DEL DÍA VALOR:
                </label>
                <input type="text" name="sumtrm" value="0" readonly="readonly" class="form-control" required="required"/>
              </div>
               <div class="form-group">
                <label for="autores">
                  COMISION BANCO:
                </label>
                <input type="text" name="num6" value="0" onchange="calva()" onkeyup="calva()" class="form-control" value="" required="required"/>
              </div>
              <div class="form-group">
                <label for="autores">
                  TOTAL DESCUENTO:
                </label>
                <input type="text" name="sumdes" value="0" readonly="readonly" class="form-control" required="required"/>
              </div>
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-default" data-dismiss="modal" style="height: 34px; border-radius: 4px; box-shadow: 5px 5px #888888; margin-right: 20px;">
                CERRAR
              </button>
              <input type="submit" name="GuardarFinanciero" value="GUARDAR FINANCIEROS" id="EtiGuar" style="height: 34px; border-radius: 4px; box-shadow: 5px 5px #888888;"/>
            </div>
          </form>
        </div>
      </div>
    </div>
    <script src="Js/Jqu.min.js"></script>
    <script src="Js/Boot.min.js"></script>
    <script>
      function calva() {
        try {
          var a = parseInt(document.f.num1.value),
              b = parseInt(document.f.num2.value);
          document.f.sum.value = (a * b) / 100;
        } catch (e) {
        }
        try {
          var c = parseInt(document.f.num1.value),
              d = parseInt(document.f.num3.value);
          document.f.sumban.value = ((c * d) / 100) / 100;
        } catch (e) {
        }
        try {
          var e = parseInt(document.f.num1.value),
              f = parseInt(document.f.num4.value);
          document.f.sumpay.value = (e * f) / 100;
        } catch (e) {
        }
        try {
          var g = parseInt(document.f.sum.value),
              h = parseInt(document.f.sumban.value);
              i = parseInt(document.f.sumpay.value);
          document.f.sumtot.value = g + h + i;
        } catch (e) {
        }
        try {
          var j = parseInt(document.f.sumtot.value),
              k = parseInt(document.f.num5.value);
          document.f.sumtrm.value = j * k;
        } catch (e) {
        }
        try {
          var l = parseInt(document.f.sumtrm.value),
              m = parseInt(document.f.num6.value);
          document.f.sumdes.value = l + m;
        } catch (e) {
        }
      }
    </script>
  </body>
  </html>
  <?php
  if(isset($_POST['GuardarFinanciero'])){
    $post_IdPrincipal = $_POST['IdPrincipal'];   
    $Post_idreferencia = $_POST['idreferencia'];
    $Post_producto = $_POST['producto'];
    $Post_pvpusd = $_POST['pvpusd'];
    $Post_transporteinternacional = $_POST['transporteinternacional'];
    $Post_num1 = $_POST['num1'];
    $Post_num2 = $_POST['num2'];
    $Post_sum = $_POST['sum'];
    $Post_num3 = $_POST['num3'];
    $Post_sumban = $_POST['sumban'];
    $Post_num4 = $_POST['num4'];
    $Post_sumpay = $_POST['sumpay'];
    $Post_sumtot = $_POST['sumtot'];
    $Post_num5 = $_POST['num5'];
    $Post_sumtrm = $_POST['sumtrm'];
    $Post_num6 = $_POST['num6'];     
    $Post_sumdes = $_POST['sumdes'];     
    mysqli_query($mysqli, "SET NAMES utf8");
    $Insert_Post = mysqli_query($mysqli, "INSERT INTO financieros (id,idreferencia,producto,pvpusd,transporteinternacional,num1,num2,sum,num3,sumban,num4,sumpay,sumtot,num5,sumtrm,num6,sumdes) VALUES ('$post_IdPrincipal','$Post_idreferencia','$Post_producto','$Post_pvpusd','$Post_transporteinternacional','$Post_num1','$Post_num2','$Post_sum','$Post_num3','$Post_sumban','$Post_num4','$Post_sumpay','$Post_sumtot','$Post_num5','$Post_sumtrm','$Post_num6','$Post_sumdes')") or die (mysqli_error($mysqli));
      echo "<script>alert('FINANCIERO AGREGADO CON EXITO!!!')</script>";
      echo "<script>window.open('Financieros.php','_self')</script>";
  }
  ?>
<?php } ?>