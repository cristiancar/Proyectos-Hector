<?php
include("Conn/conn.php");
error_reporting(E_ALL ^ E_NOTICE);
session_start();
if(!isset($_SESSION['user_name'])){
  echo "<script>alert('NO TIENES ACCESO AL ADMINISTRADOR !!!')</script>";
  echo "<script>window.open('login.php','_self')</script>";
}
else{ ?>
  <!DOCTYPE html>
  <html lang="es">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Registro De Operación</title>
    <link rel="icon" type="image/png" href="../img/icon/1.png">
    <link rel="stylesheet" href="Css/Boot.min.css">
    <link rel="stylesheet" href="Css/Esti.css">
  </head>
  <body>
    <nav class="navbar navbar-default">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">
              Toggle navigation
            </span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="index.php">
            Registro De Operación
          </a>
        </div>
        <div id="navbar" class="collapse navbar-collapse">
          <ul class="nav navbar-nav">
            <li>
              <a href="index.php">
                Panel de Control
              </a>
            </li>
            <li class="active">
              <a href="paginas.php">
                Páginas
              </a>
            </li>
            <li>
              <a href="usuarios.php">
                Usuarios
              </a>
            </li>
          </ul>
          <ul class="nav navbar-nav navbar-right">
            <li>
              <a href="index.php">
                Bienvenido, Registro De Operación
              </a>
            </li>
            <li>
              <a href="logout.php">
                Salir
              </a>
            </li>
          </ul>
        </div>
      </div>
    </nav>
    <header id="header">
      <div class="container">
        <div class="row">
          <div class="col-md-10">
            <h1>
              <span class="glyphicon glyphicon-cog" aria-hidden="true"></span>
                Páginas
              <small>
                Administrar Los Registro De Operación
              </small>
            </h1>
          </div>
          <div class="col-md-2">
            <div class="dropdown crear">
              <button class="btn btn-default dropdown-toggle" type="button" id="dropdownMenu1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
                Crear Contenido
                <span class="caret"></span>
              </button>
              <ul class="dropdown-menu" aria-labelledby="dropdownMenu1">
                <li>
                  <a type="button" data-toggle="modal" data-target="#addPage">
                    Agregar Un Nuevo Registro De Operación
                  </a>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </header>
    <section id="breadcrumb">
      <div class="container">
        <ol class="breadcrumb">
          <li>
            <a href="index.php">
              Panel de Control
            </a>
          </li>
          <li>
            Páginas
          </li>
          <li class="active">
            Ver Registro De Operación
          </li>
        </ol>
      </div>
    </section>
    <section id="main">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <div class="panel panel-default">
              <div class="panel-heading main-color-bg">
                <h3 class="panel-title">
                  INGRESO AL BANCO
                </h3>
              </div>
              <div class="panel-body table-responsive">
                <table class="table table-striped table-hover">
                  <tr>
                    <th>
                      MES:
                    </th>
                    <th>
                      CUENTA:
                    </th>
                    <th>
                      NATURALEZA:
                    </th>
                    <th>
                      NOMBRE BANCO:
                    </th>
                    <th>
                      FECHA:
                    </th>
                    <th>
                      FACTURA:
                    </th>
                    <th>
                      VALOR:
                    </th>
                    <th>
                      PAYPAL:
                    </th>
                    <th>
                      TDC:
                    </th>
                    <th>
                      DIRECTO:
                    </th>
                    <th>
                      FACTOR:
                    </th>
                    <th>
                      VALOR FACTURA:
                    </th>
                    <th>
                      TASA NEGOCIADA:
                    </th>
                    <th>
                      BANCOS:
                    </th>
                    <th>
                      DIFERENCIA EN CAMBIO:
                    </th>
                  </tr>
                  <?php
                  mysqli_set_charset($mysqli, 'utf8');
                  $get_posts = "SELECT * FROM registrodeoperacíon ORDER BY idfactura DESC";
                  $run_posts = mysqli_query($mysqli, $get_posts);
                  while ($row_posts = mysqli_fetch_array($run_posts)) {
                    $Post_Mes = $row_posts['mes'];
                    $Post_Cuenta = $row_posts['cuenta'];
                    $Post_Naturaleza = $row_posts['naturaleza'];
                    $Post_Nombre_Banco = $row_posts['nombrebanco'];
                    $Post_Fecha = $row_posts['FechaDeIngreso'];
                    $Post_Factura = $row_posts['idfactura'];
                    $Post_Valor = $row_posts['valor'];
                    $Post_Paypal = $row_posts['paypal'];
                    $Post_Tdc = $row_posts['tdc'];
                    $Post_Directo = $row_posts['directo'];
                    $Post_Factor = $row_posts['factor'];
                    $Post_Valor_Factura = $row_posts['valorfactura'];
                    $Post_Tasa_Negociada = $row_posts['tasanegociada'];
                    $Post_Bancos = $row_posts['bancos'];
                    $Post_Diferencia_En_Cambio = $row_posts['diferenciaencambio'];
                    ?>
                    <tr>
                      <td>
                        <?php echo $Post_Mes; ?>
                      </td>
                      <td>
                        <?php echo $Post_Cuenta; ?>
                      </td>
                      <td>
                        <?php echo $Post_Naturaleza; ?>
                      </td>
                      <td>
                        <?php echo $Post_Nombre_Banco; ?>
                      </td>
                      <td>
                        <?php echo $Post_Fecha; ?>
                      </td>
                      <td>
                        <?php echo $Post_Factura; ?>
                      </td>
                      <td>
                        <?php echo $Post_Valor; ?>
                      </td>
                      <td>
                        <?php echo $Post_Paypal; ?>
                      </td>
                      <td>
                        <?php echo $Post_Tdc; ?>
                      </td>
                      <td>
                        <?php echo $Post_Directo; ?>
                      </td>
                      <td>
                        <?php echo $Post_Factor; ?>
                      </td>
                      <td>
                        <?php echo $Post_Valor_Factura; ?>
                      </td>
                      <td>
                        <?php echo $Post_Tasa_Negociada; ?>
                      </td>
                      <td>
                        <?php echo $Post_Bancos; ?>
                      </td>
                      <td>
                        <?php echo $Post_Diferencia_En_Cambio; ?>
                      </td>
                    </tr>
                  <?php } ?>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <footer id="footer">
      <p>
        Powered By Imaginaudio Digital, &copy; 2020
      </p>
    </footer>
    <div class="modal fade" id="addPage" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <form name="f" action="" method="post" enctype="multipart/form-data" target="_blank" >
            <div class="modal-header">
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">
                  &times;
                </span>
              </button>
              <h4 class="modal-title" id="myModalLabel">
                Agregar Registro de Opreción
              </h4>
            </div>
            <div class="panel-body table-responsive">
              <div class="form-group">
                <label for="nombre">
                  ID PRINCIPAL:
                </label>
                <input type="text" name="IdPrincipal" class="form-control" value="" required="required"/>
              </div>
              <div class="form-group">
                <label for="nombre">
                  MES:
                </label>
                <input type="text" name="mes" class="form-control" value="" required="required"/>
              </div>
              <div class="form-group">
                <label for="nombre">
                  CUENTA:
                </label>
                <input type="text" name="cuenta" class="form-control" value="" required="required"/>
              </div>
              <div class="form-group">
                <label for="nombre">
                  NATURALEZA:
                </label>
                <input type="text" name="naturaleza" class="form-control" value="" required="required"/>
              </div>
              <div class="form-group">
                <label for="nombre">
                  NOMBRE BANCO:
                </label>
                <input type="text" name="nombrebanco" class="form-control" value="" required="required"/>
              </div>
              <div class="form-group">
                <label>
                  FECHA:
                </label>
                <input type="datetime-local" class="form-control" name="FechaDeIngreso" value="<?php echo date('Y-m-d').'T'.date('H:i'); ?>" required="required">
              </div>
              <div class="form-group">
                <label for="nombre">
                  FACTURA:
                </label>
                <input type="text" name="idfactura" class="form-control" value="" required="required"/>
              </div>
              <div class="form-group">
                <label for="autores">
                  VALOR:
                </label>
                <input type="text" name="num1" value="0" onchange="calva()" onkeyup="calva()" class="form-control" value="" required="required"/>
              </div>
              <div class="form-group">
                <label for="autores">
                  PAYPAL:
                </label>
                <input type="text" name="num3" value="0" onchange="calva()" onkeyup="calva()" class="form-control" required="required"/>
              </div>
              <div class="form-group">
                <label for="autores">
                  TDC:
                </label>
                <input type="text" name="tdc" class="form-control" value="" required="required"/>
              </div>
              <div class="form-group">
                <label for="autores">
                  DIRECTO:
                </label>
                <input type="text" name="directo" class="form-control" value="" required="required"/>
              </div>
              <div class="form-group">
                <label for="autores">
                  FACTOR:
                </label>
                <input type="text" name="num2" value="0" onchange="calva()" onkeyup="calva()" class="form-control" value="" required="required"/>
              </div>
              <div class="form-group">
                <label for="autores">
                  VALOR FACTURA:
                </label>
                <input type="text" name="sum" value="0" readonly="readonly" class="form-control" required="required"/>
              </div>
              <div class="form-group">
                <label for="autores">
                  TASA NEGOCIADA:
                </label>
                <input type="text" name="num4" value="0" onchange="calva()" onkeyup="calva()" class="form-control" required="required"/>
              </div>
              <div class="form-group">
                <label for="autores">
                  BANCOS:
                </label>
                <input type="text" name="sumban" value="0" readonly="readonly" class="form-control" value="" required="required"/>
              </div>
              <div class="form-group">
                <label for="autores">
                  DIFERENCIA EN CAMBIO:
                </label>
                <input type="text" name="sumcam" value="0" readonly="readonly" class="form-control" required="required"/>
              </div>
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-default" data-dismiss="modal" style="height: 34px; border-radius: 4px; box-shadow: 5px 5px #888888; margin-right: 20px;">
                CERRAR
              </button>
              <input type="submit" name="GuardarRegistro" value="GUARDAR REGISTRO" id="EtiGuar" style="height: 34px; border-radius: 4px; box-shadow: 5px 5px #888888;"/>
            </div>
          </form>
        </div>
      </div>
    </div>
    <script src="Js/Jqu.min.js"></script>
    <script src="Js/Boot.min.js"></script>
    <script>
      function calva() {
        try {
          var a = parseInt(document.f.num1.value),
              b = parseInt(document.f.num2.value);
          document.f.sum.value = a * b;
        } catch (e) {
        }
        try {
          var c = parseInt(document.f.num3.value),
              d = parseInt(document.f.num4.value);
          document.f.sumban.value = c * d;
        } catch (e) {
        }
        try {
          var e = parseInt(document.f.sumban.value),
              f = parseInt(document.f.sum.value);
          document.f.sumcam.value = e - f;
        } catch (e) {
        }
      }
    </script>
  </body>
  </html>
  <?php
  if(isset($_POST['GuardarRegistro'])){
    $post_IdPrincipal = $_POST['IdPrincipal'];      
    $Post_Mes = $_POST['mes'];
    $Post_cuenta = $_POST['cuenta'];
    $Post_Naturaleza = $_POST['naturaleza'];
    $Post_Nombre_Banco = $_POST['nombrebanco'];
    $FechaDeIngreso = $_POST['FechaDeIngreso'];
    $FechaDeIngreso = str_replace("T"," ",$FechaDeIngreso);
    $FechaDeIngreso = $FechaDeIngreso.":00";
    $FechaDeIngreso = ($FechaDeIngreso=="")?(null):($FechaDeIngreso);
    function check_schedule1($FechaDeIngreso){
      date_default_timezone_set('America/Bogota');
      $today1 = date('Y-m-d H:i:s');
      if($FechaDeIngreso > $today1){
        return false;
      }
      else{
        return true;
      }
    }
    $Post_Id_Factura = $_POST['idfactura'];
    $Post_Num1 = $_POST['num1'];
    $Post_Num3 = $_POST['num3'];
    $Post_Tdc = $_POST['tdc'];
    $Post_Directo = $_POST['directo'];
    $Post_Num2 = $_POST['num2'];
    $Post_Sum = $_POST['sum'];
    $Post_Num4 = $_POST['num4'];
    $Post_SumBan = $_POST['sumban'];    
    mysqli_query($mysqli, "SET NAMES utf8");
    $Insert_Post = mysqli_query($mysqli, "INSERT INTO registrodeoperacíon (id,mes,cuenta,naturaleza,nombrebanco,FechaDeIngreso,idfactura,num1,num3,tdc,directo,num2,sum,num4,sumban,sumcam) VALUES ('$post_IdPrincipal','$Post_Mes','$Post_cuenta','$Post_Naturaleza','$Post_Nombre_Banco','$FechaDeIngreso','$Post_Id_Factura','$Post_Num1','$Post_Num3','$Post_Tdc','$Post_Directo','$Post_Directo','$Post_Num2','$Post_Sum','$Post_Num4','$Post_SumBan')") or die (mysqli_error($mysqli));
      echo "<script>alert('REGISTRO AGREGADO CON EXITO!!!')</script>";
      echo "<script>window.open('RegistroDeOperacion.php','_self')</script>";
  }
  ?>
<?php } ?>