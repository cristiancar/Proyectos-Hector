<?php
	$mysqli = new mysqli('localhost', 'root', 'imaginaudio2019', 'plantilla');
	if($mysqli->connect_error){
		die('Error en la conexion' . $mysqli->connect_error);		
	}