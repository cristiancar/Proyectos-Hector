<?php include "layouts/header.php"; ?>
<div class="container">

<center><h2 style="color:black; margin-top:20%">Unamonos y vamos juntos a viajar por el mundo...</h2></center>
<center><a href="#"><img src="images/Logo.png"></a></center>
</div>

</body>
</html>
