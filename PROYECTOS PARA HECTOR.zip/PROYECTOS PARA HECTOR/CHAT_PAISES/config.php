<?php

$dbHost ='localhost';
$dbUsername ='root';
$dbPassword ='imaginaudio2019';
$dbDatabase ='tutorial_db';
$conn=mysqli_connect($dbHost,$dbUsername,$dbPassword,$dbDatabase);

?>